package com.liquidglass.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import kotlin.math.ceil
import kotlin.math.min

/** Spotlight-jaisa search: glass search bar + results panel. */
class SearchOverlay(ctx: Context, private val host: Host) : Overlay(ctx) {

    private val input = EditText(ctx).apply {
        background = null
        setTextColor(Color.WHITE)
        setHintTextColor(0x99FFFFFF.toInt())
        hint = "Search apps"
        textSize = 17f
        isSingleLine = true
        inputType = InputType.TYPE_CLASS_TEXT
        imeOptions = EditorInfo.IME_ACTION_GO
        setPadding(ctx.dpi(10f), 0, ctx.dpi(6f), 0)
    }
    private val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val holder = FrameLayout(ctx)
    private val colLp = LayoutParams(MATCH, WRAP)
    private var matches: List<AppEntry> = emptyList()

    init {
        val pad = ctx.dpi(16f)
        val pill = glassPanel(ctx, host.backdrop, 26f, tint = 0x30FFFFFF, blur = 0.12f)
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dpi(18f), 0, ctx.dpi(12f), 0)
        }
        row.addView(ImageView(ctx).apply {
            setImageResource(R.drawable.ic_cc_search)
            alpha = 0.8f
        }, LinearLayout.LayoutParams(ctx.dpi(20f), ctx.dpi(20f)))
        row.addView(input, LinearLayout.LayoutParams(0, MATCH, 1f))
        pill.addView(row, LayoutParams(MATCH, MATCH))
        col.addView(pill, LinearLayout.LayoutParams(MATCH, ctx.dpi(52f)))
        col.addView(holder, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dpi(12f) })
        colLp.leftMargin = pad
        colLp.rightMargin = pad
        colLp.topMargin = ctx.dpi(60f)
        addView(col, colLp)

        input.doAfterTextChanged { showResults(it?.toString() ?: "") }
        input.setOnEditorActionListener { _, _, _ ->
            matches.firstOrNull()?.let { host.launch(it, input) }
            true
        }
    }

    fun setInsets(top: Int) {
        colLp.topMargin = top + dpi(16f)
        col.layoutParams = colLp
    }

    override fun onOpen() {
        input.setText("")
        holder.removeAllViews()
        input.postDelayed({
            input.requestFocus()
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }, 200)
    }

    override fun onClosing() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        input.clearFocus()
    }

    private fun showResults(q: String) {
        holder.removeAllViews()
        matches = emptyList()
        if (q.isBlank()) return
        matches = host.allApps()
            .filter { it.label.contains(q, ignoreCase = true) }
            .sortedBy { if (it.label.startsWith(q, ignoreCase = true)) 0 else 1 }
            .take(6)
        val g = glassPanel(context, host.backdrop, 26f, tint = 0x30FFFFFF, blur = 0.12f)
        val list = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(8f), dpi(8f), dpi(8f), dpi(8f))
        }
        if (matches.isEmpty()) {
            list.addView(TextView(context).apply {
                text = "No apps found"
                setTextColor(0xCCFFFFFF.toInt())
                textSize = 16f
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(MATCH, dpi(56f)))
        }
        for (e in matches) {
            val r = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpi(8f), 0, dpi(8f), 0)
                isClickable = true
                setOnClickListener { host.launch(e, it) }
            }
            r.addView(AppIconView(context).apply {
                entry = e
                showLabel = false
                iconDp = 40f
                isClickable = false
            }, LinearLayout.LayoutParams(dpi(48f), dpi(48f)))
            r.addView(TextView(context).apply {
                text = e.label
                setTextColor(Color.WHITE)
                textSize = 17f
                setPadding(dpi(12f), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            list.addView(r, LinearLayout.LayoutParams(MATCH, dpi(56f)))
        }
        g.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        holder.addView(g, FrameLayout.LayoutParams(MATCH, WRAP))
    }
}

/** App Library category (ya folder) ka bada glass panel. */
class CategoryOverlay(ctx: Context, private val host: Host) : Overlay(ctx) {

    private val holder = FrameLayout(ctx)

    init {
        addView(holder, LayoutParams(MATCH, MATCH))
    }

    fun show(cat: Cat, apps: List<AppEntry>) {
        holder.removeAllViews()
        val g = glassPanel(context, host.backdrop, 34f, tint = 0x33FFFFFF, blur = 0.12f)
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(12f), dpi(16f), dpi(12f), dpi(12f))
        }
        col.addView(TextView(context).apply {
            text = cat.title
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dpi(8f), 0, 0, dpi(8f))
        }, LinearLayout.LayoutParams(MATCH, WRAP))

        val rowH = dpi(98f)
        val rows = ceil(apps.size / 4f).toInt().coerceAtLeast(1)
        val maxH = (resources.displayMetrics.heightPixels * 0.6f).toInt()
        val scroll = ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val grid = PageGrid(context, 4, rows, rowH)
        for (e in apps) grid.addView(makeIcon(context, host, e, true, 60f, false))
        scroll.addView(grid, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, min(rows * rowH, maxH)))

        g.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        holder.addView(g, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER).apply {
            leftMargin = dpi(16f)
            rightMargin = dpi(16f)
        })
        open()
    }
}

/** Long-press menu (glass popup). */
class MenuOverlay(ctx: Context, private val host: Host) : Overlay(ctx) {

    private var panel: View? = null

    init {
        scrim.setBackgroundColor(0x22000000)
    }

    fun show(x: Float, y: Float, items: List<Pair<String, () -> Unit>>) {
        panel?.let { removeView(it) }
        val g = glassPanel(context, host.backdrop, 20f, tint = 0x48FFFFFF, blur = 0.12f)
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dpi(6f), 0, dpi(6f))
        }
        for (item in items) {
            col.addView(TextView(context).apply {
                text = item.first
                setTextColor(Color.WHITE)
                textSize = 16f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpi(18f), 0, dpi(18f), 0)
                isClickable = true
                setOnClickListener {
                    close()
                    item.second()
                }
            }, LinearLayout.LayoutParams(MATCH, dpi(48f)))
        }
        g.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        val w = dpi(230f)
        val h = items.size * dpi(48f) + dpi(12f)
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        val left = (x - w / 2f).toInt().coerceIn(dpi(12f), (sw - w - dpi(12f)).coerceAtLeast(dpi(12f)))
        var top = y.toInt() + dpi(12f)
        if (top + h > sh - dpi(24f)) top = (y - h - dpi(12f)).toInt()
        top = top.coerceIn(host.insetTop + dpi(8f), (sh - h - dpi(8f)).coerceAtLeast(host.insetTop + dpi(8f)))
        addView(g, LayoutParams(w, WRAP).apply {
            leftMargin = left
            topMargin = top
        })
        panel = g
        open()
    }
}
