package com.liquidglass.launcher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.animation.DecelerateInterpolator
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.example.liquidglass.LiquidGlassToast
import com.example.liquidglass.LiquidGlassView
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.min

class LauncherActivity : Activity(), Host, NotificationHub.Listener {

    private lateinit var root: GestureFrame
    private lateinit var backdropLayer: FrameLayout
    private lateinit var wallpaper: ImageView
    private lateinit var pagerBox: FrameLayout
    private lateinit var pager: ViewPager2
    private lateinit var pagesAdapter: PagesAdapter
    private lateinit var dots: DotsView
    private lateinit var dock: LiquidGlassView
    private lateinit var dockRow: LinearLayout

    private lateinit var controlCenter: ControlCenterView
    private lateinit var notifCenter: NotificationCenterView
    private lateinit var search: SearchOverlay
    private lateinit var category: CategoryOverlay
    private lateinit var menu: MenuOverlay
    private lateinit var banner: BannerView

    private var apps: List<AppEntry> = emptyList()
    private var appsVersion = 0
    private var loaded = false
    private var topInset = 0
    private var bottomInset = 0
    private var lastBuildKey = ""
    private var badgeCounts: Map<String, Int> = emptyMap()
    private var resumed = false
    private val bg = Executors.newSingleThreadExecutor()

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            reloadApps()
        }
    }

    // ------------------------------------------------------------------ Host

    override val backdrop: View get() = backdropLayer
    override val wallpaperView: View get() = wallpaper
    override val insetTop: Int get() = topInset
    override val insetBottom: Int get() = bottomInset

    override fun allApps(): List<AppEntry> = apps

    override fun badgeFor(pkg: String): Int = badgeCounts[pkg] ?: 0

    override fun toast(msg: String) {
        try {
            LiquidGlassToast.makeText(this, msg).show()
        } catch (e: Exception) {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    override fun startSafe(intent: Intent) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: Exception) {
            toast("Ye option is phone pe available nahi hai")
        }
    }

    override fun launch(e: AppEntry, anchor: View) {
        closeOverlays()
        try {
            val loc = IntArray(2)
            anchor.getLocationOnScreen(loc)
            val r = Rect(loc[0], loc[1], loc[0] + anchor.width, loc[1] + anchor.height)
            val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            la.startMainActivity(e.component, e.user, r, null)
        } catch (t: Throwable) {
            try {
                startActivity(
                    Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setComponent(e.component)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (t2: Throwable) {
                toast("Can't open " + e.label)
            }
        }
    }

    override fun closeOverlays() {
        if (::menu.isInitialized) menu.close()
        if (::category.isInitialized) category.close()
        if (::search.isInitialized) search.close()
        if (::controlCenter.isInitialized) controlCenter.close()
        if (::notifCenter.isInitialized) notifCenter.close()
    }

    private fun anyOverlayOpen(): Boolean =
        menu.isOpen || category.isOpen || search.isOpen || controlCenter.isOpen || notifCenter.isOpen

    override fun openSearch() {
        closeOverlays()
        search.open()
    }

    override fun openCategory(cat: Cat, apps: List<AppEntry>) {
        category.show(cat, apps)
    }

    private fun rootPoint(rawX: Float, rawY: Float): Pair<Float, Float> {
        val l = IntArray(2)
        root.getLocationOnScreen(l)
        return Pair(rawX - l[0], rawY - l[1])
    }

    override fun showAppMenu(e: AppEntry, anchor: View, inDock: Boolean) {
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val p = rootPoint(loc[0] + anchor.width / 2f, loc[1] + anchor.height.toFloat())
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("App info" to { showAppInfo(e) })
        items.add((if (inDock) "Remove from Dock" else "Add to Dock") to { toggleDock(e, inDock) })
        items.add("Uninstall" to { uninstall(e) })
        menu.show(p.first, p.second, items)
    }

    override fun showHomeMenu(rawX: Float, rawY: Float) {
        val p = rootPoint(rawX, rawY)
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("Change wallpaper" to { pickWallpaper() })
        items.add("Notification access" to { startSafe(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        items.add("Allow system settings" to {
            startSafe(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        })
        items.add("Default home app" to { startSafe(Intent(Settings.ACTION_HOME_SETTINGS)) })
        menu.show(p.first, p.second, items)
    }

    // -------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        buildUi()
        setContentView(root)
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        loadWallpaper()
        reloadApps()
        root.requestApplyInsets()
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        NotificationHub.addListener(this)
        NotificationHub.addListener(notifCenter)
        onNotificationsChanged()
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        NotificationHub.removeListener(this)
        NotificationHub.removeListener(notifCenter)
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        if (controlCenter.isOpen) controlCenter.refresh()
        onNotificationsChanged()
    }

    override fun onPause() {
        super.onPause()
        resumed = false
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null && intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            closeOverlays()
            pager.setCurrentItem(0, true)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            menu.isOpen -> menu.close()
            category.isOpen -> category.close()
            search.isOpen -> search.close()
            controlCenter.isOpen -> controlCenter.close()
            notifCenter.isOpen -> notifCenter.close()
            pager.currentItem != 0 -> pager.setCurrentItem(0, true)
            else -> {
                // launcher: home pe back se kuch nahi hota
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bg.shutdown()
    }

    // --------------------------------------------------------------------- UI

    private fun buildUi() {
        root = GestureFrame(this)

        backdropLayer = FrameLayout(this)
        wallpaper = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        backdropLayer.addView(wallpaper, FrameLayout.LayoutParams(MATCH, MATCH))

        pagerBox = FrameLayout(this)
        pagesAdapter = PagesAdapter(this, this)
        pager = ViewPager2(this)
        pager.adapter = pagesAdapter
        pager.offscreenPageLimit = 1
        pager.setPageTransformer { page, position ->
            val p = position.coerceIn(-1f, 1f)
            page.translationX = -p * page.width * 0.08f
            page.scaleX = 1f - 0.045f * kotlin.math.abs(p)
            page.scaleY = 1f - 0.045f * kotlin.math.abs(p)
            page.alpha = 1f - 0.22f * kotlin.math.abs(p)
            page.cameraDistance = 12000f * resources.displayMetrics.density
        }
        (pager.getChildAt(0) as? RecyclerView)?.apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            itemAnimator = null
            setHasFixedSize(true)
        }
        dots = DotsView(this)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                dots.setPosition(position + positionOffset)
            }
        })
        pagerBox.addView(pager, FrameLayout.LayoutParams(MATCH, MATCH))
        pagerBox.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> root.post { maybeRebuild() } }
        backdropLayer.addView(pagerBox, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(backdropLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        root.addView(dots, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        dots.alpha = 0.82f

        dock = glassPanel(this, backdropLayer, 34f, tint = 0x26FFFFFF, blur = 0.1f)
        dockRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(10f), 0, dpi(10f), 0)
        }
        dock.addView(dockRow, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(dock, FrameLayout.LayoutParams(MATCH, dpi(88f), Gravity.BOTTOM))

        controlCenter = ControlCenterView(this, this)
        notifCenter = NotificationCenterView(this, this)
        search = SearchOverlay(this, this)
        category = CategoryOverlay(this, this)
        menu = MenuOverlay(this, this)
        banner = BannerView(this, this)
        root.addView(controlCenter, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(notifCenter, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(search, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(category, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(menu, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(banner, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        root.onSwipeDown = { x, y ->
            if (!anyOverlayOpen()) {
                val zone = topInset + dpi(170f)
                if (y < zone) {
                    if (x < root.width / 2f) notifCenter.open() else controlCenter.open()
                } else if (pager.currentItem < pagesAdapter.itemCount - 1) {
                    openSearch()
                }
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val sb = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            topInset = sb.top
            bottomInset = sb.bottom
            applyInsets()
            insets
        }
        applyInsets()
    }

    private fun lp(v: View) = v.layoutParams as FrameLayout.LayoutParams

    private fun applyInsets() {
        val dockH = dpi(88f)
        val dockMargin = dpi(14f)
        lp(dock).apply {
            height = dockH
            leftMargin = dpi(18f)
            rightMargin = dpi(18f)
            bottomMargin = bottomInset + dockMargin
        }
        lp(dots).bottomMargin = bottomInset + dockMargin + dockH + dpi(6f)
        lp(pagerBox).apply {
            topMargin = topInset
            bottomMargin = bottomInset + dockMargin + dockH + dpi(26f)
        }
        lp(banner).topMargin = topInset + dpi(8f)
        lp(banner).leftMargin = dpi(12f)
        lp(banner).rightMargin = dpi(12f)
        dock.requestLayout()
        pagerBox.requestLayout()
        controlCenter.setInsets(topInset, bottomInset)
        notifCenter.setInsets(topInset, bottomInset)
        search.setInsets(topInset)
    }

    // ------------------------------------------------------------------ data

    private fun reloadApps() {
        bg.execute {
            val list: List<AppEntry> = try {
                AppRepository.load(this)
            } catch (t: Throwable) {
                emptyList()
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                apps = list
                appsVersion++
                loaded = true
                badgeCounts = NotificationHub.counts(this)
                maybeRebuild()
            }
        }
    }

    private fun maybeRebuild() {
        val h = pagerBox.height
        if (h <= 0 || !loaded) return
        val cellH = dpi(98f)
        val widgetH = dpi(136f)
        val rows1 = (h / cellH).coerceIn(3, 7)
        val rows0 = ((h - widgetH) / cellH).coerceIn(2, 6)
        val dockList = dockEntries()
        val dockKeys = dockList.map { it.key }
        val key = "$rows0|$rows1|$appsVersion|${dockKeys.joinToString(",")}|${badgeCounts.hashCode()}"
        if (key == lastBuildKey) return
        lastBuildKey = key

        val dockSet = dockKeys.toSet()
        val grid = apps.filter { it.key !in dockSet }
        val pages = ArrayList<List<AppEntry>>()
        var i = 0
        var first = true
        do {
            val cap = 4 * (if (first) rows0 else rows1)
            val end = min(grid.size, i + cap)
            pages.add(grid.subList(i, end))
            i = end
            first = false
        } while (i < grid.size)

        val cur = pager.currentItem
        pagesAdapter.setData(pages, rows0, rows1, apps)
        dots.count = pages.size + 1
        if (cur < pagesAdapter.itemCount && cur > 0) pager.setCurrentItem(cur, false)

        dockRow.removeAllViews()
        dock.visibility = if (dockList.isEmpty()) View.GONE else View.VISIBLE
        for (e in dockList) {
            dockRow.addView(makeIcon(this, this, e, false, 56f, true), LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    private fun dockEntries(): List<AppEntry> {
        val keys = Prefs.dock(this)
        var list = keys.mapNotNull { k -> apps.firstOrNull { it.key == k } }
        if (list.isEmpty() && apps.isNotEmpty()) {
            list = defaultDock()
            Prefs.setDock(this, list.map { it.key })
        }
        return list.take(4)
    }

    private fun defaultDock(): List<AppEntry> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        val out = ArrayList<AppEntry>()
        for (intent in intents) {
            val ri = try {
                packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            } catch (e: Exception) {
                null
            }
            val pkg = ri?.activityInfo?.packageName ?: continue
            val match = apps.firstOrNull { it.pkg == pkg } ?: continue
            if (out.none { it.key == match.key }) out.add(match)
        }
        for (a in apps) {
            if (out.size >= 4) break
            if (out.none { it.key == a.key }) out.add(a)
        }
        return out
    }

    private fun toggleDock(e: AppEntry, inDock: Boolean) {
        val keys = Prefs.dock(this).toMutableList()
        if (inDock) {
            keys.remove(e.key)
        } else {
            if (keys.size >= 4) {
                toast("Dock full hai, pehle kuch hatao")
                return
            }
            keys.add(e.key)
        }
        Prefs.setDock(this, keys)
        maybeRebuild()
    }

    private fun showAppInfo(e: AppEntry) {
        try {
            val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            la.startAppDetailsActivity(e.component, e.user, null, null)
        } catch (t: Throwable) {
            startSafe(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + e.pkg))
            )
        }
    }

    private fun uninstall(e: AppEntry) {
        startSafe(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + e.pkg)))
    }

    // ----------------------------------------------------------- notifications

    override fun onNotificationsChanged() {
        if (!::notifCenter.isInitialized) return
        val c = NotificationHub.counts(this)
        if (c != badgeCounts) {
            badgeCounts = c
            maybeRebuild()
        }
    }

    override fun onNotificationPosted(item: NotificationHub.Item) {
        if (resumed && !notifCenter.isOpen && !search.isOpen) banner.show(item)
    }

    // --------------------------------------------------------------- wallpaper

    private fun loadWallpaper() {
        val f = File(filesDir, "wallpaper.jpg")
        if (f.exists()) {
            val bmp = BitmapFactory.decodeFile(f.path)
            if (bmp != null) {
                wallpaper.setImageBitmap(bmp)
                return
            }
        }
        wallpaper.setImageResource(R.drawable.ios_wallpaper)
    }

    private fun pickWallpaper() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        try {
            startActivityForResult(i, REQ_WALLPAPER)
        } catch (e: Exception) {
            toast("Gallery/file picker nahi mila")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_WALLPAPER || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            try {
                val dm = resources.displayMetrics
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= dm.widthPixels &&
                    bounds.outHeight / (sample * 2) >= dm.heightPixels
                ) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp != null) {
                    File(filesDir, "wallpaper.jpg").outputStream().use {
                        bmp.compress(Bitmap.CompressFormat.JPEG, 92, it)
                    }
                    runOnUiThread { wallpaper.setImageBitmap(bmp) }
                } else {
                    runOnUiThread { toast("Image load nahi hui") }
                }
            } catch (t: Throwable) {
                runOnUiThread { toast("Image load nahi hui") }
            }
        }.start()
    }

    private companion object {
        const val REQ_WALLPAPER = 4711
    }
}
