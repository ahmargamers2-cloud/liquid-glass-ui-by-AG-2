package com.liquidglass.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.min

/** Icons ka grid: cols x rows cells, har cell equal size. */
class PageGrid(
    ctx: Context,
    private val cols: Int,
    private val rows: Int,
    private val fixedRowHeightPx: Int = 0
) : ViewGroup(ctx) {

    var lastRawX = 0f
    var lastRawY = 0f

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            lastRawX = ev.rawX
            lastRawY = ev.rawY
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val cellW = w / cols
        val rowCount = ceil(childCount / cols.toFloat()).toInt().coerceAtLeast(1)
        val cellH: Int
        val h: Int
        if (fixedRowHeightPx > 0) {
            cellH = fixedRowHeightPx
            h = cellH * rowCount
        } else {
            h = MeasureSpec.getSize(hSpec)
            cellH = h / rows.coerceAtLeast(1)
        }
        for (i in 0 until childCount) {
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(cellW, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(cellH, MeasureSpec.EXACTLY)
            )
        }
        setMeasuredDimension(w, h)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val cellW = w / cols
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val col = i % cols
            val row = i / cols
            val x = col * cellW
            val y = row * v.measuredHeight
            v.layout(x, y, x + cellW, y + v.measuredHeight)
        }
    }
}

fun makeIcon(ctx: Context, host: Host, e: AppEntry, withLabel: Boolean, iconDp: Float, inDock: Boolean): AppIconView {
    return AppIconView(ctx).apply {
        entry = e
        showLabel = withLabel
        this.iconDp = iconDp
        badge = host.badgeFor(e.pkg)
        setOnClickListener { host.launch(e, it) }
        setOnLongClickListener {
            host.showAppMenu(e, it, inDock)
            true
        }
    }
}

/** Glass clock/date widget (sirf wallpaper ko backdrop banata hai). */
class ClockWidget(ctx: Context, host: Host) : FrameLayout(ctx) {
    init {
        val glass = glassPanel(ctx, host.wallpaperView, 28f, tint = 0x22FFFFFF, blur = 0.1f)
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dpi(22f), 0, ctx.dpi(22f), 0)
        }
        val time = TextClock(ctx).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            setTextColor(Color.WHITE)
            textSize = 48f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setShadowLayer(8f, 0f, 2f, 0x55000000)
        }
        val date = TextClock(ctx).apply {
            format12Hour = "EEEE, d MMMM"
            format24Hour = "EEEE, d MMMM"
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        col.addView(time, LinearLayout.LayoutParams(WRAP, WRAP))
        col.addView(date, LinearLayout.LayoutParams(WRAP, WRAP))
        glass.addView(col, LayoutParams(MATCH, MATCH))
        addView(glass, LayoutParams(MATCH, MATCH))
    }
}

/** Ek home page: (pehle page pe widget) + icon grid. */
class HomePageView(
    ctx: Context,
    host: Host,
    apps: List<AppEntry>,
    withWidget: Boolean,
    rows: Int
) : LinearLayout(ctx) {
    init {
        orientation = VERTICAL
        if (withWidget) {
            addView(
                ClockWidget(ctx, host),
                LayoutParams(MATCH, ctx.dpi(120f)).apply {
                    leftMargin = ctx.dpi(18f)
                    rightMargin = ctx.dpi(18f)
                    topMargin = ctx.dpi(8f)
                    bottomMargin = ctx.dpi(8f)
                }
            )
        }
        val grid = PageGrid(ctx, 4, rows)
        for (e in apps) grid.addView(makeIcon(ctx, host, e, true, 60f, false))
        grid.setOnLongClickListener {
            host.showHomeMenu(grid.lastRawX, grid.lastRawY)
            true
        }
        addView(grid, LayoutParams(MATCH, 0, 1f))
    }
}

/** App Library: categories ke glass-jaise tiles. */
class LibraryView(ctx: Context, private val host: Host, apps: List<AppEntry>) : ScrollView(ctx) {

    init {
        isVerticalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dpi(18f), ctx.dpi(12f), ctx.dpi(18f), ctx.dpi(24f))
        }

        root.addView(TextView(ctx).apply {
            text = "App Library"
            setTextColor(Color.WHITE)
            textSize = 28f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setShadowLayer(8f, 0f, 2f, 0x55000000)
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { bottomMargin = ctx.dpi(10f) })

        // search pill
        val pill = SearchPill(ctx).apply { setOnClickListener { host.openSearch() } }
        root.addView(pill, LinearLayout.LayoutParams(MATCH, ctx.dpi(46f)).apply { bottomMargin = ctx.dpi(16f) })

        val groups = Cat.values().map { c -> c to apps.filter { it.cat == c } }.filter { it.second.isNotEmpty() }
        val gap = ctx.dpi(14f)
        var i = 0
        while (i < groups.size) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0 until 2) {
                val g = groups.getOrNull(i + j)
                val cell = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                if (g != null) {
                    val tile = CategoryTile(ctx, host, g.first, g.second)
                    cell.addView(tile, LinearLayout.LayoutParams(MATCH, 0, 1f))
                    cell.addView(TextView(ctx).apply {
                        text = g.first.title
                        setTextColor(0xE6FFFFFF.toInt())
                        textSize = 13f
                        gravity = Gravity.CENTER
                        setShadowLayer(4f, 0f, 1f, 0x66000000)
                    }, LinearLayout.LayoutParams(MATCH, ctx.dpi(26f)))
                }
                row.addView(cell, LinearLayout.LayoutParams(0, MATCH, 1f).apply {
                    if (j == 0) rightMargin = gap / 2 else leftMargin = gap / 2
                })
            }
            val tileH = (ctx.resources.displayMetrics.widthPixels - ctx.dpi(36f) - gap) / 2 + ctx.dpi(26f)
            root.addView(row, LinearLayout.LayoutParams(MATCH, tileH).apply { bottomMargin = gap })
            i += 2
        }
        addView(root, LayoutParams(MATCH, WRAP))
    }
}

class SearchPill(ctx: Context) : View(ctx) {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(1f)
        color = 0x55FFFFFF
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCCFFFFFF.toInt()
        textSize = ctx.dp(16f)
    }
    private val icon = ctx.getDrawable(R.drawable.ic_cc_search)?.mutate()

    init {
        isClickable = true
    }

    override fun onDraw(c: Canvas) {
        val r = height / 2f
        val rect = RectF(1f, 1f, width - 1f, height - 1f)
        c.drawRoundRect(rect, r, r, bg)
        c.drawRoundRect(rect, r, r, rim)
        val s = dpi(18f)
        val x = dpi(16f)
        icon?.setBounds(x, (height - s) / 2, x + s, (height + s) / 2)
        icon?.alpha = 200
        icon?.draw(c)
        c.drawText("Search apps", (x + s + dpi(10f)).toFloat(), height / 2f + txt.textSize * 0.35f, txt)
    }
}

/** Category tile: 2x2 mini icons (plain translucent, performance ke liye). */
class CategoryTile(ctx: Context, host: Host, cat: Cat, apps: List<AppEntry>) : FrameLayout(ctx) {

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x2EFFFFFF }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(1.2f)
        color = 0x66FFFFFF
    }

    init {
        setWillNotDraw(false)
        isClickable = true
        setOnClickListener { host.openCategory(cat, apps) }
        val pad = ctx.dpi(12f)
        setPadding(pad, pad, pad, pad)
        val grid = PageGrid(ctx, 2, 2)
        for (e in apps.take(4)) {
            grid.addView(makeIcon(ctx, host, e, false, 34f, false))
        }
        addView(grid, LayoutParams(MATCH, MATCH))
    }

    override fun onDraw(c: Canvas) {
        val r = dp(26f)
        val rect = RectF(1f, 1f, width - 1f, height - 1f)
        c.drawRoundRect(rect, r, r, bg)
        c.drawRoundRect(rect, r, r, rim)
        super.onDraw(c)
    }
}

class DotsView(ctx: Context) : View(ctx) {
    var count = 0
        set(v) {
            field = v
            requestLayout()
            invalidate()
        }
    private var pos = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    fun setPosition(v: Float) {
        pos = v
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(count * dpi(14f) + dpi(8f), dpi(14f))
    }

    override fun onDraw(c: Canvas) {
        val step = dp(14f)
        for (i in 0 until count) {
            val near = 1f - min(1f, abs(i - pos))
            p.alpha = (90 + 165 * near).toInt()
            c.drawCircle(dp(4f) + step * i + step / 2f, height / 2f, dp(3.3f), p)
        }
    }
}

class PagesAdapter(private val host: Host, private val ctx: Context) :
    RecyclerView.Adapter<PagesAdapter.VH>() {

    class VH(val frame: FrameLayout) : RecyclerView.ViewHolder(frame)

    private var pages: List<List<AppEntry>> = emptyList()
    private var rows0 = 4
    private var rows1 = 5
    private var all: List<AppEntry> = emptyList()

    fun setData(p: List<List<AppEntry>>, r0: Int, r1: Int, allApps: List<AppEntry>) {
        pages = p
        rows0 = r0
        rows1 = r1
        all = allApps
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = pages.size + 1

    override fun getItemViewType(position: Int): Int = if (position < pages.size) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val f = FrameLayout(parent.context)
        f.layoutParams = RecyclerView.LayoutParams(MATCH, MATCH)
        return VH(f)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.frame.removeAllViews()
        val v: View = if (position < pages.size) {
            HomePageView(ctx, host, pages[position], position == 0, if (position == 0) rows0 else rows1)
        } else {
            LibraryView(ctx, host, all)
        }
        holder.frame.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
    }
}
