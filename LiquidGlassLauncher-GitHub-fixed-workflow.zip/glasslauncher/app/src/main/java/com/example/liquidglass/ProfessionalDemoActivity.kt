/**
 * LiquidGlass 专业演示 Activity
 *
 * 功能特性：
 * - 4 个演示场景：滚动背景 / 图片背景 / 动画背景 / 多组件展示
 * - 卡片式现代调试面板（按 渲染路径 / 玻璃参数 / 色彩效果 分组，
 *   CPU 算法选项仅在强制 CPU 时显示）
 * - 实时性能监控（读取 LiquidGlassView.FrameStats）
 * - 背景图片选择、中英文切换
 */
package com.example.liquidglass

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.VelocityTracker
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.example.liquidglass.demo.R
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.abs
import kotlin.math.roundToInt

class ProfessionalDemoActivity : AppCompatActivity() {

    // ==================== 场景 ====================

    private enum class Scene(val labelRes: Int) {
        PLAYGROUND(R.string.scene_playground),
        HOME(R.string.scene_home),
        CONTROL_CENTER(R.string.scene_control_center),
        MERGE(R.string.scene_merge),
        BACKDROP(R.string.scene_backdrop),
        LIST(R.string.scene_list),
        OVERLAYS(R.string.scene_overlays),
        WIDGETS(R.string.scene_widgets),
        TEXT(R.string.scene_text)
    }

    private var currentScene = Scene.PLAYGROUND

    /** 调参场的背景：渐变 / 图片 / 动画光斑，场景内切换 */
    private enum class PlaygroundBackdrop(val labelRes: Int) {
        GRADIENT(R.string.playground_bg_gradient),
        IMAGE(R.string.playground_bg_image),
        ANIMATED(R.string.playground_bg_animated)
    }

    private var playgroundBackdrop = PlaygroundBackdrop.GRADIENT

    /** backdropSource 场景的拓扑：兄弟子树 / 跨层级祖先 */
    private enum class BackdropMode(val labelRes: Int, val hintRes: Int) {
        SIBLING(R.string.backdrop_mode_sibling, R.string.backdrop_hint_sibling),
        ANCESTOR(R.string.backdrop_mode_ancestor, R.string.backdrop_hint_ancestor)
    }

    private var backdropMode = BackdropMode.SIBLING

    /** 控制中心对照场景的页面：主页 / 点网络模块展开的二级页 */
    private enum class ControlCenterPage { MAIN, CONNECTIVITY }

    /** 控制中心里网络开关的状态，主页和二级页共用，切页不丢 */
    private class ControlCenterState {
        var airplane = false
        var airdrop = true
        var wifi = true
        var cellular = true
        var bluetooth = true
        var hotspot = false
        var rotationLock = true
        var flashlight = false
        var record = false
        var focus = false
        var brightness = 0.34f
        var volume = 0f
    }

    private val ccState = ControlCenterState()

    /** 控制中心场景里 demo 自己的控件是否显示；每次进场景都先藏起来 */
    private var controlCenterChromeShown = false
    private var controlCenterHintShown = false

    private var controlCenterPage = ControlCenterPage.MAIN

    /** 控制中心场景的背景：桌面截图整屏模糊后的位图，跨页复用 */
    private var controlCenterBackdrop: Bitmap? = null

    /** 控制中心关着时看到的清晰桌面 */
    private var controlCenterHome: Bitmap? = null

    /** 控制中心是否拉开着：切页重建时保持，收起时回到主页 */
    private var controlCenterOpen = false

    // ==================== 视图 ====================

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var sceneHost: FrameLayout
    private lateinit var glassView: LiquidGlassView
    private val extraGlassViews = mutableListOf<LiquidGlassView>()
    private lateinit var fabSettings: FloatingActionButton
    private lateinit var githubButton: LiquidGlassButton
    private lateinit var tvPerformanceOverlay: TextView
    private lateinit var tvDebugInfo: TextView
    private lateinit var sceneBarScroll: HorizontalScrollView
    private val sceneChips = mutableListOf<TextView>()

    // 动态显隐的面板分组
    private lateinit var cpuOptionsGroup: LinearLayout
    private lateinit var lensGroup: LinearLayout
    private lateinit var aberrationGroup: LinearLayout
    private lateinit var dispersionGroup: LinearLayout

    // 性能监控数据源（融合场景使用场景内的玻璃视图）
    private var statsSource: LiquidGlassView? = null

    // 弹层场景的对话框与其中的玻璃（跨 window，切场景/销毁时必须关掉）
    private var bottomSheetDialog: BottomSheetDialog? = null
    private var sheetGlass: LiquidGlassView? = null

    /** 状态栏高度，由 window insets 回填。场景里顶部对齐的文字/组件靠它避开状态栏与性能悬浮窗 */
    private var systemBarTop = 0
    private var systemBarBottom = 0

    private var customBackgroundBitmap: Bitmap? = null
    private var scenicBitmap: Bitmap? = null

    // 性能监控
    private val performanceHandler = Handler(Looper.getMainLooper())
    private var isMonitoring = true

    // ==================== 系统 ====================

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri -> loadBackgroundImage(uri) }
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) openImagePicker()
        else showGlassToast(getString(R.string.toast_no_image_selected))
    }

    companion object {
        // 以下都是从 iOS 26 真机截图上取的色
        const val CC_SCRIM = 0x8C0A0A0A.toInt()   // 底子压到 45% 亮度，黑底留一点底（iOS 的黑约 14）
        const val CC_FROST = 0x40FFFFFF          // 模块的白色散射
        const val CC_BLUR_AMOUNT = 0.2f           // 模块内部再糊一层；再大采样区就盖到邻居，每帧要多录十几次
        const val CC_BLUE = 0xFF2D92FB.toInt()
        const val CC_GREEN = 0xFF64CB6E.toInt()
        const val CC_RED = 0xFFEC6B69.toInt()
        const val CC_YELLOW = 0xFFF7CE45.toInt()
        const val CC_INACTIVE = 0x38FFFFFF        // 非激活的实心圆
        const val CC_DISABLED = 0x24FFFFFF        // 不可用（VPN）的实心圆
        const val CC_INSET = 0x1AFFFFFF           // 正在播放里的封面位 / AirPlay 圆
        const val CC_MOON_CIRCLE = 0x4DFFFFFF
        const val CC_SUBTITLE = 0x99FFFFFF.toInt()
        const val CC_CONTROL_DIM = 0x4DFFFFFF     // 上一曲 / 下一曲
        const val CC_RAIL_DIM = 0x66FFFFFF        // 右侧页面指示的非当前页
        const val CC_INDIGO = 0xFF5E5CE6.toInt()  // 专注模式激活
        const val CC_ON_WHITE = 0xFF3A3A3C.toInt() // 白底上的图标

        private const val TAG = "ProfessionalDemo"
        private const val PREF_NAME = "LiquidGlassPrefs"
        private const val KEY_LANGUAGE = "language"
        private const val LANG_ENGLISH = "en"
        private const val LANG_CHINESE = "zh"
        private const val REPO_URL = "https://github.com/QWEA0/Liquid-Glass-Android"

        private const val COLOR_BG = 0xFFF2F2F7.toInt()       // 面板底色
        private const val COLOR_SCROLL_GUTTER = 0xFF0B1020.toInt()  // 滚动场景上下留白底色
        private const val COLOR_CARD = 0xFFFFFFFF.toInt()     // 卡片
        private const val COLOR_TEXT = 0xFF111111.toInt()     // 主文字
        private const val COLOR_TEXT_DIM = 0xFF8E8E93.toInt() // 次要文字
        private const val COLOR_ACCENT = 0xFF007AFF.toInt()   // 强调色
        private const val COLOR_SEG_BG = 0xFFE9E9EB.toInt()   // 分段控件底

        /** 色块背景（渐变起止色 + 标签）：滚动色块和小部件场景的翻页背景共用 */
        private val COLOR_BANDS = listOf(
            Triple(0xFFFF6B6B.toInt(), 0xFFC0392B.toInt(), "🌹 Red"),
            Triple(0xFF4ECDC4.toInt(), 0xFF16A085.toInt(), "🌊 Cyan"),
            Triple(0xFF45B7D1.toInt(), 0xFF2C3E90.toInt(), "💙 Blue"),
            Triple(0xFFFFA07A.toInt(), 0xFFE67E22.toInt(), "🍊 Orange"),
            Triple(0xFF98D8C8.toInt(), 0xFF27AE60.toInt(), "🌿 Green"),
            Triple(0xFFF7DC6F.toInt(), 0xFFF39C12.toInt(), "⭐ Yellow"),
            Triple(0xFFBB8FCE.toInt(), 0xFF8E44AD.toInt(), "💜 Purple"),
            Triple(0xFF85C1E2.toInt(), 0xFF2980B9.toInt(), "☁️ Sky")
        )

        /** 抽屉染色卡片的色板（名称 + 色相，取 iOS 系统色）；第一项是"取消染色" */
        private val TINT_SWATCHES = listOf(
            R.string.tint_none to Color.TRANSPARENT,
            R.string.tint_blue to 0xFF0A84FF.toInt(),
            R.string.tint_cyan to 0xFF32ADE6.toInt(),
            R.string.tint_green to 0xFF30D158.toInt(),
            R.string.tint_yellow to 0xFFFFD60A.toInt(),
            R.string.tint_orange to 0xFFFF9F0A.toInt(),
            R.string.tint_red to 0xFFFF453A.toInt(),
            R.string.tint_pink to 0xFFFF375F.toInt(),
            R.string.tint_purple to 0xFFBF5AF2.toInt()
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedLanguage()
        super.onCreate(savedInstanceState)
        // 演示页全屏展示玻璃效果，ActionBar 只会挡住场景和性能悬浮窗。
        // 同时让场景铺到系统栏底下——玻璃拖到屏幕边缘时不该被一条纯色带截断。
        supportActionBar?.hide()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        createGlassView()
        createMainLayout()
        // adb shell am start ... --es scene group：直接打开指定场景（取 Scene 枚举名，不分大小写）
        val requested = intent.getStringExtra("scene")?.let { name ->
            Scene.entries.firstOrNull { it.name.equals(name, ignoreCase = true) }
        }
        showScene(requested ?: Scene.PLAYGROUND)
        startPerformanceMonitoring()
    }

    // ==================== 布局骨架 ====================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun dpF(v: Int): Float = v * resources.displayMetrics.density

    private fun createGlassView() {
        val label = TextView(this).apply {
            text = getString(R.string.glass_button_text)
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(36), dp(28), dp(36), dp(28))
            setShadowLayer(8f, 0f, 2f, Color.BLACK)
        }
        glassView = LiquidGlassView(this).apply {
            id = View.generateViewId()
            enableDynamicBackground = true
            addView(label)
            // 自适应外观：背景变亮时前景文字切换为深色（Apple Regular 玻璃行为）
            glassAppearanceListener = { isOverLight ->
                if (isOverLight) {
                    label.setTextColor(0xDE000000.toInt())
                    label.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
                } else {
                    label.setTextColor(Color.WHITE)
                    label.setShadowLayer(8f, 0f, 2f, Color.BLACK)
                }
            }
        }
    }

    private fun createMainLayout() {
        drawerLayout = DrawerLayout(this)

        val mainContent = FrameLayout(this)

        // 场景容器（背景 + 玻璃组件都在这里，父视图捕获不会带上 UI 覆盖层）
        sceneHost = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        mainContent.addView(sceneHost)

        // 性能悬浮窗
        tvPerformanceOverlay = TextView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                // 顶部间距在下面按真实状态栏 inset 设置：API 35+ 强制 edge-to-edge，
                // mainContent 从窗口顶端起算，硬编码的 dp 值会被状态栏/刘海盖住
                setMargins(dp(8), dp(8), dp(8), 0)
            }
            background = GradientDrawable().apply {
                cornerRadius = dpF(10)
                setColor(0xCC000000.toInt())
            }
            setTextColor(0xFF4CFF7A.toInt())
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(6), dp(10), dp(6))
            text = getString(R.string.performance_waiting)
        }
        mainContent.addView(tvPerformanceOverlay)

        // 左上角的仓库入口：下载 APK 试效果的人大多没打开过仓库页，这里给一条回去的路。
        // 用库自己的玻璃按钮，顺带多一个真实场景里的小部件
        githubButton = LiquidGlassButton(this).apply {
            enableDynamicBackground = true
            enableAdaptiveTint = true
            text = getString(R.string.github_star_button)
            setTextSize(13f)
            textView.setPadding(dp(16), dp(9), dp(16), dp(9))
            // 小胶囊：库默认的斜面是给大面板定的，按高度收一档，折射取斜面的一半
            bevelWidth = dpF(14)
            refractionHeight = dpF(7)
            edgeSoftness = dpF(3)
            setOnClickListener { openRepo() }
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                // 顶部间距在下面按真实状态栏 inset 设置
                setMargins(dp(12), dp(8), 0, 0)
            }
        }
        mainContent.addView(githubButton)

        // 场景切换条
        val sceneBar = createSceneBar()
        mainContent.addView(sceneBar)

        // 设置按钮
        fabSettings = FloatingActionButton(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                setMargins(0, 0, dp(20), dp(96))
            }
            setImageResource(android.R.drawable.ic_menu_preferences)
            setOnClickListener { drawerLayout.openDrawer(GravityCompat.END) }
        }
        mainContent.addView(fabSettings)

        // 只有覆盖层让开系统栏，场景内容仍然铺满全屏。
        // 不要用固定 dp 值：状态栏高度随刘海/挖孔变化，手势条与三键导航也差一倍。
        ViewCompat.setOnApplyWindowInsetsListener(mainContent) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val topChanged = bars.top != systemBarTop
            systemBarTop = bars.top
            systemBarBottom = bars.bottom
            // 首个场景在 onCreate 里就建好了，那时 systemBarTop 还是 0；
            // 靠它避开状态栏 / 性能悬浮窗的场景内控件要等 inset 到了再重建一次
            if (topChanged) sceneHost.post { showScene(currentScene) }
            (tvPerformanceOverlay.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(8)
                rightMargin = bars.right + dp(8)
            }
            (githubButton.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(8)
                leftMargin = bars.left + dp(12)
            }
            (sceneBar.layoutParams as FrameLayout.LayoutParams).bottomMargin = bars.bottom + dp(16)
            (fabSettings.layoutParams as FrameLayout.LayoutParams).apply {
                bottomMargin = bars.bottom + dp(84)
                rightMargin = bars.right + dp(20)
            }
            tvPerformanceOverlay.requestLayout()
            githubButton.requestLayout()
            sceneBar.requestLayout()
            fabSettings.requestLayout()
            insets
        }

        drawerLayout.addView(mainContent)
        drawerLayout.addView(createDrawer())
        setContentView(drawerLayout)
    }

    private fun createSceneBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
        }

        Scene.entries.forEach { scene ->
            val chip = TextView(this).apply {
                text = getString(scene.labelRes)
                textSize = 13f
                gravity = Gravity.CENTER
                // 一行放不下时必须单行截断：被挤窄的 chip 会逐字换行，
                // 把整条 bar 撑成几倍高（黑底跟着变高就是这么来的）
                maxLines = 1
                setPadding(dp(13), dp(8), dp(13), dp(8))
                setOnClickListener { if (currentScene != scene) showScene(scene) }
            }
            sceneChips += chip
            bar.addView(chip)
        }

        // 场景数量超过一屏宽度后改为横向滚动，而不是把 chip 压扁。
        // 胶囊底色和圆角裁剪都挂在滚动容器（视口）上，这样无论内容多宽，
        // 看到的始终是一颗完整的、不出屏的胶囊，chip 在里面滚动
        sceneBarScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            // 两端渐隐提示还能往左右滚，而不是把文字硬切断
            isHorizontalFadingEdgeEnabled = true
            setFadingEdgeLength(dp(20))
            background = GradientDrawable().apply {
                cornerRadius = dpF(22)
                setColor(0xB3000000.toInt())
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dpF(22))
                }
            }
            clipToOutline = true
            setPadding(dp(6), dp(6), dp(6), dp(6))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(28)
                leftMargin = dp(12)
                rightMargin = dp(12)
            }
            addView(bar)
        }
        return sceneBarScroll
    }

    private fun updateSceneBar() {
        Scene.entries.forEachIndexed { i, scene ->
            val chip = sceneChips[i]
            if (scene == currentScene) {
                chip.background = GradientDrawable().apply {
                    cornerRadius = dpF(18)
                    setColor(Color.WHITE)
                }
                chip.setTextColor(COLOR_TEXT)
                chip.typeface = Typeface.DEFAULT_BOLD
            } else {
                chip.background = null
                chip.setTextColor(0xFFDDDDDD.toInt())
                chip.typeface = Typeface.DEFAULT
            }
        }

        // 选中项滚进可视区（切场景时它可能在屏幕外）
        val selected = sceneChips[Scene.entries.indexOf(currentScene)]
        sceneBarScroll.post {
            sceneBarScroll.smoothScrollTo(
                selected.left - (sceneBarScroll.width - selected.width) / 2, 0
            )
        }
    }

    // ==================== 场景 ====================

    private fun showScene(scene: Scene) {
        val previous = currentScene
        currentScene = scene
        extraGlassViews.clear()
        (glassView.parent as? ViewGroup)?.removeView(glassView)
        sceneHost.removeAllViews()
        statsSource = glassView
        // HOME 场景会给共享的 glassView 装拖动监听并改 translation，切走时必须还原，
        // 否则其他场景的居中布局会被上次拖动的位移带偏
        glassView.setOnTouchListener(null)
        glassView.translationX = 0f
        glassView.translationY = 0f
        // BACKDROP 场景会把背景来源指到场景内的视图上，切走时必须解绑，
        // 否则其他场景的玻璃还在捕获一棵已经被移除的子树
        glassView.backdropSource = null
        // TEXT 场景会改软键盘模式，切走时还原
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        // OVERLAYS 场景的弹层在独立 window 里，不随 sceneHost 的清空而消失
        dismissGlassBottomSheet()

        val root = when (scene) {
            Scene.PLAYGROUND -> buildPlaygroundScene()
            Scene.HOME -> buildHomeScene()
            Scene.CONTROL_CENTER -> buildControlCenterScene()
            Scene.MERGE -> buildMergeScene()
            Scene.BACKDROP -> buildBackdropScene()
            Scene.LIST -> buildListScene()
            Scene.OVERLAYS -> buildOverlaysScene()
            Scene.WIDGETS -> buildWidgetsScene()
            Scene.TEXT -> buildTextScene()
        }
        sceneHost.addView(root)
        updateSceneBar()
        // 控制中心场景藏起 demo 控件和系统栏；inset 变化引起的重建不算"进场景"，保持用户切过的状态
        when {
            scene == Scene.CONTROL_CENTER -> {
                if (previous != scene) {
                    controlCenterChromeShown = false
                    if (!controlCenterHintShown) {
                        controlCenterHintShown = true
                        showGlassToast(getString(R.string.cc_hint))
                    }
                }
                setDemoChromeVisible(controlCenterChromeShown)
            }
            previous == Scene.CONTROL_CENTER -> setDemoChromeVisible(true)
        }
    }

    private fun centerGlassParams(): FrameLayout.LayoutParams =
        FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER }

    /** 场景内顶部居中的切换条位置：让开状态栏和性能悬浮窗 */
    private fun topToggleParams(): FrameLayout.LayoutParams =
        FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = systemBarTop + dp(96)
        }

    /**
     * 场景内的小切换条：深底胶囊里一排 chip，选中的白底加粗（与底部场景条同一套样式）。
     * 选中态由这里维护，回调只管做事
     */
    private fun buildChipToggle(
        labels: List<String>,
        selectedIndex: Int,
        onSelect: (Int) -> Unit
    ): View {
        val chips = mutableListOf<TextView>()
        fun render(selected: Int) {
            chips.forEachIndexed { i, chip ->
                if (i == selected) {
                    chip.background = GradientDrawable().apply {
                        cornerRadius = dpF(18)
                        setColor(Color.WHITE)
                    }
                    chip.setTextColor(COLOR_TEXT)
                    chip.typeface = Typeface.DEFAULT_BOLD
                } else {
                    chip.background = null
                    chip.setTextColor(0xFFDDDDDD.toInt())
                    chip.typeface = Typeface.DEFAULT
                }
            }
        }
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadius = dpF(22)
                setColor(0xB3000000.toInt())
            }
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        labels.forEachIndexed { i, label ->
            val chip = TextView(this).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(dp(16), dp(8), dp(16), dp(8))
                setOnClickListener {
                    render(i)
                    onSelect(i)
                }
            }
            chips += chip
            pill.addView(chip)
        }
        render(selectedIndex)
        return pill
    }

    /**
     * 场景 1：调参场 —— 主玻璃 + 三种可切换的背景：
     * - 渐变：彩色色块滚动 + 顶部渐进模糊（ScrollEdgeBlurView）
     * - 图片：用户选的图或程序生成的风景图，平铺两份可滚动
     * - 动画：渐变光斑持续运动，考验动态背景的实时性
     *
     * 抽屉里的参数直接作用在主玻璃上。背景 chip 挂在 stage 外面，不会被玻璃采进去
     */
    private fun buildPlaygroundScene(): View {
        val root = FrameLayout(this)
        val stage = FrameLayout(this)
        root.addView(stage, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        when (playgroundBackdrop) {
            PlaygroundBackdrop.GRADIENT -> {
                val scroll = createColorScroll()
                stage.addView(scroll)
                // 顶部渐进模糊（Scroll Edge Effect：内容滚入顶部时从清晰渐变到模糊）
                val edgeBlur = ScrollEdgeBlurView(this).apply {
                    edge = ScrollEdgeBlurView.Edge.TOP
                    maxBlurRadius = dpF(14)
                    layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, dp(110)
                    ).apply { gravity = Gravity.TOP }
                }
                edgeBlur.bindScrollView(scroll)
                stage.addView(edgeBlur)
            }
            PlaygroundBackdrop.IMAGE -> {
                val scroll = ScrollView(this).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                    isVerticalScrollBarEnabled = false
                }
                val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                val bitmap = customBackgroundBitmap ?: getOrCreateScenicBitmap()
                // 平铺 2 份以支持滚动
                repeat(2) {
                    content.addView(ImageView(this).apply {
                        setImageBitmap(bitmap)
                        scaleType = ImageView.ScaleType.FIT_XY
                        adjustViewBounds = true
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                    })
                }
                scroll.addView(content)
                stage.addView(scroll)
            }
            PlaygroundBackdrop.ANIMATED -> {
                stage.addView(AnimatedBlobView(this).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                })
            }
        }

        glassView.layoutParams = centerGlassParams()
        stage.addView(glassView)

        root.addView(
            buildChipToggle(
                PlaygroundBackdrop.entries.map { getString(it.labelRes) },
                playgroundBackdrop.ordinal
            ) { index ->
                playgroundBackdrop = PlaygroundBackdrop.entries[index]
                showScene(Scene.PLAYGROUND)
            },
            topToggleParams()
        )
        return root
    }

    /**
     * 场景 7：玻璃文字（原型，尚未进库）—— 输入什么字，那几个字就是玻璃。
     *
     * 走的是 [GlassTextPrototypeView]：文字轮廓烘成距离场喂进透镜着色器，
     * 于是折射/色散/高光落在笔画上，而不是一个矩形容器上。
     * 背景用桌面壁纸 + 图标网格：折射在平滑渐变上根本看不出来。
     */
    private fun buildTextScene(): View {
        val root = FrameLayout(this)
        statsSource = null   // 本场景不含 LiquidGlassView，性能悬浮窗无数据源

        // 键盘弹起时不要压缩布局，否则居中的玻璃字会被顶到 tab 栏后面
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)

        // 背景：iOS 风格壁纸，纵向可滚动。第二张上下翻转，接缝处颜色连续
        val backdrop = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            repeat(2) { i ->
                addView(ImageView(this@ProfessionalDemoActivity).apply {
                    setImageResource(R.drawable.text_backdrop)
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    if (i == 1) scaleY = -1f
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                })
            }
        }
        root.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setBackgroundColor(0xFF060B18.toInt())
            addView(backdrop)
        }, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val glassText = GlassTextPrototypeView(this).apply {
            textSizePx = dpF(125)
            text = getString(R.string.text_scene_default)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.CENTER }
        }
        root.addView(glassText)

        // 输入不即时生效：连打连删会反复重烘距离场（一次数百毫秒），
        // 改成点右侧按钮或按回车才提交
        val input = EditText(this).apply {
            setText(glassText.text)
            hint = getString(R.string.text_scene_hint)
            textSize = 16f
            setTextColor(Color.WHITE)
            setHintTextColor(0x99FFFFFF.toInt())
            background = GradientDrawable().apply {
                cornerRadius = dpF(14)
                setColor(0x59000000)
                setStroke(dp(1), 0x40FFFFFF)
            }
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_DONE
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        val applyText = {
            glassText.text = input.text.toString()
            input.clearFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(input.windowToken, 0)
        }
        val applyButton = TextView(this).apply {
            text = getString(R.string.text_scene_apply)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = dpF(14)
                setColor(COLOR_ACCENT)
            }
            setPadding(dp(18), dp(13), dp(18), dp(13))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = dp(8) }
            setOnClickListener { applyText() }
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                applyText()
                true
            } else {
                false
            }
        }
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(input)
            addView(applyButton)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP
                topMargin = systemBarTop + dp(72)
                leftMargin = dp(24)
                rightMargin = dp(24)
            }
        })
        root.addView(buildTextParamPanel(glassText))

        // 场景里只有输入框可聚焦，进场景就会自动弹键盘把效果挡住；
        // 让根容器先接住焦点，用户点了输入框才弹
        root.isFocusableInTouchMode = true
        root.requestFocus()

        return root
    }

    /**
     * 玻璃字调参面板
     *
     * 顶部那行等宽绿字是当前全部参数的汇总——调舒服了直接照着它报数即可。
     * 字号/斜面/折射三项会触发距离场重烘，视图内部有 60ms 合并，拖滑杆不会每步都算。
     */
    private fun buildTextParamPanel(glass: GlassTextPrototypeView): View {
        val density = resources.displayMetrics.density

        val summary = TextView(this).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFF4CFF7A.toInt())
            setPadding(0, dp(4), 0, dp(4))
        }
        var tintDark = false
        var tintAlpha = Color.alpha(glass.tint)

        fun refreshSummary() {
            summary.text = ("size=%.0fdp blur=%.0f bevel=%.2f refr=%.2f disp=%.2f\n" +
                "spec=%.2f shadow=%.2f sat=%.0f tint=%s@%d").format(
                glass.textSizePx / density,
                glass.blurRadius, glass.bevelFactor, glass.refractFactor, glass.dispersion,
                glass.specStrength, glass.innerShadow, glass.saturation,
                if (tintDark) "#000" else "#fff", tintAlpha
            )
        }

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panelSlider(body, getString(R.string.param_size), 24, 160, (glass.textSizePx / density).toInt(), { "$it" }) {
            glass.textSizePx = dpF(it); refreshSummary()
        }
        panelSlider(body, getString(R.string.param_blur), 0, 60, glass.blurRadius.toInt(), { "$it" }) {
            glass.blurRadius = it.toFloat(); refreshSummary()
        }
        panelSlider(body, getString(R.string.param_bevel), 2, 30, (glass.bevelFactor * 100).toInt(), { "%.2f".format(it / 100f) }) {
            glass.bevelFactor = it / 100f; refreshSummary()
        }
        panelSlider(body, getString(R.string.param_refract), 2, 70, (glass.refractFactor * 100).toInt(), { "%.2f".format(it / 100f) }) {
            glass.refractFactor = it / 100f; refreshSummary()
        }
        panelSlider(body, getString(R.string.param_dispersion), 0, 60, (glass.dispersion * 100).toInt(), { "%.2f".format(it / 100f) }) {
            glass.dispersion = it / 100f; refreshSummary()
        }
        panelSlider(body, getString(R.string.param_spec), 0, 400, (glass.specStrength * 100).toInt(), { "%.2f".format(it / 100f) }) {
            glass.specStrength = it / 100f; refreshSummary()
        }
        panelSlider(body, getString(R.string.param_shadow), 0, 250, (glass.innerShadow * 100).toInt(), { "%.2f".format(it / 100f) }) {
            glass.innerShadow = it / 100f; refreshSummary()
        }
        panelSlider(body, getString(R.string.param_saturation), 50, 220, glass.saturation.toInt(), { "$it%" }) {
            glass.saturation = it.toFloat(); refreshSummary()
        }
        panelSlider(body, getString(R.string.param_tint), 0, 120, tintAlpha, { "$it" }) {
            tintAlpha = it
            val c = if (tintDark) 0 else 255
            glass.tint = Color.argb(tintAlpha, c, c, c)
            refreshSummary()
        }
        body.addView(TextView(this).apply {
            text = getString(R.string.param_tint_light)
            textSize = 12f
            setTextColor(0xFF4CA6FF.toInt())
            setPadding(0, dp(10), 0, dp(6))
            setOnClickListener {
                tintDark = !tintDark
                text = getString(if (tintDark) R.string.param_tint_dark else R.string.param_tint_light)
                val c = if (tintDark) 0 else 255
                glass.tint = Color.argb(tintAlpha, c, c, c)
                refreshSummary()
            }
        })

        // 滑杆多，装进固定高度的滚动区，免得面板顶满整屏
        val bodyScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(body)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(230)
            )
        }

        val header = TextView(this).apply {
            text = "▾ " + getString(R.string.text_param_title)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(2))
            setOnClickListener {
                val show = bodyScroll.visibility != View.VISIBLE
                bodyScroll.visibility = if (show) View.VISIBLE else View.GONE
                text = (if (show) "▾ " else "▸ ") + getString(R.string.text_param_title)
            }
        }

        refreshSummary()

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dpF(16)
                setColor(0xE60E0E12.toInt())
            }
            setPadding(dp(14), dp(10), dp(14), dp(10))
            addView(header)
            addView(summary)
            addView(bodyScroll)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM
                leftMargin = dp(12)
                rightMargin = dp(12)
                // 让开底部的场景切换条，并且高过设置 FAB——否则 FAB 会压住汇总行右端
                bottomMargin = dp(152)
            }
        }
    }

    /** 面板里的深色滑杆：标签自带当前值 */
    private fun panelSlider(
        parent: LinearLayout,
        label: String,
        min: Int,
        max: Int,
        initial: Int,
        display: (Int) -> String,
        onChange: (Int) -> Unit
    ) {
        val clamped = initial.coerceIn(min, max)
        val tv = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFDDDDDD.toInt())
            text = "$label   ${display(clamped)}"
            setPadding(0, dp(6), 0, 0)
        }
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = clamped - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    tv.text = "$label   ${display(v)}"
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) = Unit
                override fun onStopTrackingTouch(sb: SeekBar?) = Unit
            })
        }
        parent.addView(tv)
        parent.addView(seek)
    }

    /**
     * 场景：背景源 —— 玻璃和背景**没有父子关系**，背景由 [LiquidGlassView.backdropSource] 指定；
     * 默认的"捕获直接父容器"在这里只会拍到透明，画面全黑。两种拓扑可切换：
     * - 兄弟子树：玻璃套在一层全透明的宿主容器里，backdropSource 指向旁边的列表内容，
     *   滚动时的重绘由该 API 自动挂的滚动监听触发
     * - 跨层级祖先：玻璃埋在 stage 下面两层容器里，backdropSource 直接指到 stage。
     *   这是 issue #12 的崩溃条件：stage → 玻璃 路径上的中间容器此刻正在录制自己的
     *   RenderNode，天真地 source.draw() 会对它重入 beginRecording；见 BackdropCapture
     *
     * 文字行提供高频边界，折射没对齐一眼能看出来。切换条和提示挂在 stage 外，不参与捕获。
     */
    private fun buildBackdropScene(): View {
        val root = FrameLayout(this)
        val stage = FrameLayout(this)
        root.addView(stage, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(80), 0, dp(160))
        }
        repeat(24) { i ->
            content.addView(TextView(this).apply {
                text = "ROW $i  ▍▍▍  ROW $i  ▍▍▍"
                textSize = 20f
                setTextColor(if (i % 2 == 0) Color.WHITE else 0xFFFFE066.toInt())
                setBackgroundColor(if (i % 2 == 0) 0xFF1B3A6B.toInt() else 0xFF0B1D3A.toInt())
                setPadding(dp(16), dp(16), dp(16), dp(16))
                maxLines = 1
            })
        }
        stage.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setBackgroundColor(COLOR_SCROLL_GUTTER)
            addView(content)
        }, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        glassView.layoutParams = centerGlassParams()
        when (backdropMode) {
            BackdropMode.SIBLING -> {
                // 玻璃挂在独立的透明子树里：背景只能靠 backdropSource 拿到
                val isolatedHost = FrameLayout(this)
                isolatedHost.addView(glassView)
                glassView.backdropSource = content
                stage.addView(isolatedHost, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))
            }
            BackdropMode.ANCESTOR -> {
                // stage > outer > inner > 玻璃：中间隔两层容器
                val inner = FrameLayout(this).apply { addView(glassView) }
                val outer = FrameLayout(this).apply {
                    addView(inner, FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    ))
                }
                glassView.backdropSource = stage
                stage.addView(outer, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))
            }
        }

        root.addView(
            buildChipToggle(
                BackdropMode.entries.map { getString(it.labelRes) },
                backdropMode.ordinal
            ) { index ->
                backdropMode = BackdropMode.entries[index]
                showScene(Scene.BACKDROP)
            },
            topToggleParams()
        )
        root.addView(TextView(this).apply {
            text = getString(backdropMode.hintRes)
            textSize = 13f
            setTextColor(0xCCFFFFFF.toInt())
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
            gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM
            bottomMargin = dp(120)
            leftMargin = dp(20)
            rightMargin = dp(20)
        })
        return root
    }

    /**
     * 场景：弹层 —— 底部弹层 / 玻璃弹窗 / 玻璃 Toast 三个入口。
     * 底部弹层的玻璃在 [BottomSheetDialog] 里，背景取自 Activity 的内容视图。
     *
     * 这是**跨 window** 的用法。弹层自带一个独立 window，玻璃在那个 window 里的直接父容器
     * 是透明的，默认的"捕获直接父容器"只会拍到空白，所以背景必须用
     * [LiquidGlassView.backdropSource] 指到 Activity 的 content view 上。两个 window 之间的
     * 偏移由屏幕坐标算（见 GlassLensRenderer 的 getLocationOnScreen），这条路保留 GPU 管线。
     *
     * 另有两处 Material 默认行为必须关掉，否则玻璃底下不是壁纸：
     * - 弹层的窗口变暗（dim）画在 Activity 之上、弹层之下，玻璃采到的是**没变暗**的内容，
     *   折射出来会比周围亮一截，所以 dimAmount 归零
     * - design_bottom_sheet 容器默认白底，不清成透明的话玻璃背后是一层白
     */
    private fun buildOverlaysScene(): View {
        val root = FrameLayout(this)

        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ios_wallpaper)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // 图标网格提供高频边界，弹层滑动时的折射变化才看得出来
        root.addView(HomeScreenGridView(this), FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // 三个入口：BottomSheetDialog 和 AlertDialog 都是跨 window 采背景；Toast 自带 window，
        // 叠在弹层上面（弹层里也有一个 Toast 入口）
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(Button(this@ProfessionalDemoActivity).apply {
                text = getString(R.string.sheet_open)
                setOnClickListener { showGlassBottomSheet() }
            })
            addView(Button(this@ProfessionalDemoActivity).apply {
                text = getString(R.string.sheet_dialog_open)
                setOnClickListener { showGlassDialog() }
            })
            addView(Button(this@ProfessionalDemoActivity).apply {
                text = getString(R.string.sheet_toast_open)
                setOnClickListener {
                    showGlassToast(
                        getString(R.string.sheet_toast_text),
                        applicationInfo.loadIcon(packageManager)
                    )
                }
            })
        }, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER })

        return root
    }

    /** 打开仓库页：demo 的 APK 多是从 release 页直接下的，很多人没看过 README */
    private fun openRepo() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(REPO_URL)))
        } catch (e: ActivityNotFoundException) {
            showGlassToast(REPO_URL)
        }
    }

    /**
     * 玻璃 Toast：自带 window，叠在 Activity 和打开着的弹层上面，背景是底下各层 window 拼出的画面。
     * 底部抬高到场景条和设置按钮之上；彩色图标（应用图标）不跟文字染色
     */
    private fun showGlassToast(text: CharSequence, icon: Drawable? = null) {
        LiquidGlassToast.makeText(this, text, LiquidGlassToast.LENGTH_SHORT)
            .setIcon(icon)
            .setIconTintEnabled(false)
            .setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, dp(150))
            .show()
    }

    /** 玻璃弹窗：面板整个套进 LiquidGlassView，背景来自 Activity 的 content view */
    private fun showGlassDialog() {
        LiquidGlassDialogBuilder(this)
            .setTitle(R.string.sheet_dialog_title)
            .setMessage(R.string.sheet_dialog_body)
            .setPositiveButton(android.R.string.ok, null)
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showGlassBottomSheet() {
        dismissGlassBottomSheet()

        // 关键一行：背景来源跨到 Activity 的 window。
        // 注意必须显式取 Activity 的 content view——写在 glass.apply {} 里的话
        // findViewById 会解析成 View 自己的那个，在玻璃子树里找不到，静默返回 null，
        // 背景来源退回默认的直接父容器（弹层里是透明的），画面全黑
        val activityContent = findViewById<View>(android.R.id.content)

        // 玻璃比可见高度多出 CORNER 的量并用负 margin 顶到屏幕外，
        // 这样下面两个圆角被切掉，只剩上边圆角——iOS 弹层的形状
        val visibleH = dp(300)
        val overshoot = dp(40)
        val glass = newExtraGlass(dpF(28)).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, visibleH + overshoot
            ).apply { bottomMargin = -overshoot }
            backdropSource = activityContent
        }
        glass.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(12), dp(24), overshoot + dp(24))
            // iOS 弹层顶部的拖拽指示条
            addView(View(this@ProfessionalDemoActivity).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dpF(3)
                    setColor(0x80FFFFFF.toInt())
                }
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(5)).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    bottomMargin = dp(20)
                }
            })
            addView(TextView(this@ProfessionalDemoActivity).apply {
                text = getString(R.string.sheet_title)
                textSize = 20f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setShadowLayer(6f, 0f, 1f, Color.BLACK)
            })
            addView(TextView(this@ProfessionalDemoActivity).apply {
                text = getString(R.string.sheet_body)
                textSize = 13f
                setTextColor(0xFFEEEEEE.toInt())
                gravity = Gravity.CENTER
                setShadowLayer(6f, 0f, 1f, Color.BLACK)
                setPadding(0, dp(10), 0, 0)
            })
            // 从弹层里弹 Toast：Toast 的 window 叠在弹层之上，折射的是弹层和它底下的场景
            addView(TextView(this@ProfessionalDemoActivity).apply {
                text = getString(R.string.sheet_toast_open)
                textSize = 14f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    cornerRadius = dpF(20)
                    setColor(0x33FFFFFF)
                }
                setPadding(dp(20), dp(10), dp(20), dp(10))
                setOnClickListener {
                    showGlassToast(
                        getString(R.string.sheet_toast_text),
                        applicationInfo.loadIcon(packageManager)
                    )
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(18)
            })
        }, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val sheetRoot = FrameLayout(this).apply { addView(glass) }

        sheetGlass = glass
        statsSource = glass
        bottomSheetDialog = BottomSheetDialog(this, R.style.Theme_LiquidGlass_GlassBottomSheet).apply {
            setContentView(sheetRoot)

            // 变暗层夹在 Activity 和弹层之间，玻璃采不到它，留着就会亮暗不接
            window?.setDimAmount(0f)
            // 弹层的黑底来自这几层，只清 design_bottom_sheet 不够：
            // window 自己的 windowBackground、外层 container、CoordinatorLayout 都要清
            window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            // 导航栏的深色底衬（edge-to-edge 由主题开，见 Theme.LiquidGlass.GlassBottomSheet）
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window?.isNavigationBarContrastEnforced = false
            }
            findViewById<View>(com.google.android.material.R.id.container)
                ?.setBackgroundColor(Color.TRANSPARENT)
            findViewById<View>(com.google.android.material.R.id.coordinator)
                ?.setBackgroundColor(Color.TRANSPARENT)
            val sheet = findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            sheet?.setBackgroundColor(Color.TRANSPARENT)
            sheet?.elevation = 0f

            // 默认的进出场是 **window 动画**：SurfaceFlinger 直接平移整个 window 的 surface，
            // window 内的 view 树全程不重绘，getLocationOnScreen 不变，玻璃只能按动画前的
            // 偏移采样——看起来就是"最后一帧被拖着走"，没有动态折射。
            // 解法：关掉 window 动画，把位移放进 view 树里自己做，并逐帧 invalidate 玻璃，
            // 强制重录 display list、重算跨 window 偏移。
            window?.setWindowAnimations(0)

            // 拖拽/收起同理：BottomSheetBehavior 用 offsetTopAndBottom 挪容器，
            // 不会重录子视图的 display list，必须在 onSlide 里手动 invalidate
            behavior.skipCollapsed = true
            behavior.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
                override fun onStateChanged(bottomSheet: View, newState: Int) = glass.invalidate()
                override fun onSlide(bottomSheet: View, slideOffset: Float) = glass.invalidate()
            })
            // 收起走 behavior 的动画（会触发 onSlide），而不是 window 动画
            setDismissWithAnimation(true)

            setOnShowListener {
                if (sheet == null) return@setOnShowListener
                // 首帧还没布局时 height 为 0，先按 alpha 藏住，post 到布局后再起手
                sheet.alpha = 0f
                sheet.post {
                    sheet.translationY = sheet.height.toFloat()
                    sheet.alpha = 1f
                    sheet.animate()
                        .translationY(0f)
                        .setDuration(340)
                        .setInterpolator(DecelerateInterpolator(1.8f))
                        .setUpdateListener { glass.invalidate() }
                        .start()
                }
            }
            show()
        }
    }

    private fun dismissGlassBottomSheet() {
        bottomSheetDialog?.dismiss()
        bottomSheetDialog = null
        sheetGlass?.let { extraGlassViews.remove(it) }
        sheetGlass = null
    }

    /**
     * 场景 5：iOS 桌面 —— 壁纸 + 4×6 图标网格 + 可拖动的玻璃药丸。
     *
     * 这是 README 首屏用的构图，也是调参时最该用的场景：图标网格提供高频边界，
     * 折射的边缘压缩环和色散彩边才看得出来。在渐变背景的场景里调 [LiquidGlassView.refractionHeight]
     * 或 [LiquidGlassView.dispersionStrength] 基本看不出差别。
     */
    private fun buildHomeScene(): View {
        val root = FrameLayout(this)

        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ios_wallpaper)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        root.addView(HomeScreenGridView(this), FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        glassView.layoutParams = FrameLayout.LayoutParams(dp(300), dp(112)).apply {
            gravity = Gravity.CENTER
        }
        glassView.setOnTouchListener(object : View.OnTouchListener {
            private var dx = 0f
            private var dy = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dx = v.translationX - e.rawX
                        dy = v.translationY - e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        v.translationX = e.rawX + dx
                        v.translationY = e.rawY + dy
                    }
                }
                return false  // 继续交给 LiquidGlassView 自己的按压形变逻辑
            }
        })
        root.addView(glassView)
        return root
    }

    /**
     * 场景：iOS 控制中心对照 —— 用同一张 iOS 26 桌面截图做背景，模块的位置、尺寸、颜色和
     * 文字都按真机截图逐像素量出来摆，图标照 SF Symbols 的样子手绘成矢量图，
     * 好和 iOS 截图并排比玻璃本身的差距。
     *
     * 手势照 iOS：初始是清晰的桌面，从上往下拉，背景渐渐模糊压暗、模块从上方滑入，松手按
     * 进度和速度弹开或回弹；打开后往上滑收起。点网络模块的空白处展开二级页，点二级页的
     * 空白处收回。亮度 / 音量能拖，方向锁、手电、录屏、专注和网络开关都能切换。
     *
     * 控制中心的底子是"整屏模糊 + 压暗"，玻璃再在上面采样。背景用库的 CPU 模糊做一次
     * 存成位图，不用 RenderEffect：每块玻璃采样父容器时都会把整屏模糊重跑一遍。
     * 坐标按 iOS 的 pt 写（430pt 宽的屏），乘 屏幕宽 / 430 折算，窄屏上整体等比缩小。
     * 模块里的文字照抄 iOS 的英文，不做本地化。
     * 这个场景会藏起 demo 自己的控件和系统栏，让截图里只剩控制中心；点右上角的电源图标切回。
     */
    private fun buildControlCenterScene(): View {
        val matchParent = FrameLayout.LayoutParams.MATCH_PARENT
        val wrapContent = FrameLayout.LayoutParams.WRAP_CONTENT
        val stage = ControlCenterStage(this)
        fun full() = FrameLayout.LayoutParams(matchParent, matchParent)

        val home = controlCenterHome
            ?: BitmapFactory.decodeResource(resources, R.drawable.ios_control_center_bg).also { controlCenterHome = it }
        val backdrop = controlCenterBackdrop
            ?: buildControlCenterBackdrop().also { controlCenterBackdrop = it }
        // 清晰的桌面（关着时看到的），上面盖模糊版和压暗层，透明度跟下拉进度走
        val homeView = ImageView(this).apply {
            setImageBitmap(home)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        stage.addView(homeView, full())
        val blurView = ImageView(this).apply {
            setImageBitmap(backdrop)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0f
        }
        stage.addView(blurView, full())
        val scrim = View(this).apply {
            setBackgroundColor(CC_SCRIM)
            alpha = 0f
        }
        stage.addView(scrim, full())

        val scale = resources.displayMetrics.widthPixels / 430f
        fun px(v: Float): Int = Math.round(v * scale)
        fun pxF(v: Float): Float = v * scale
        fun lp(x: Float, y: Float, w: Float, h: Float) =
            FrameLayout.LayoutParams(px(w), px(h)).apply {
                leftMargin = px(x)
                topMargin = px(y)
            }
        val white = Color.WHITE
        val state = ccState
        var firstGlass: LiquidGlassView? = null

        // 控制中心图层：直接挂在舞台上的视图都算，随下拉进度平移、淡入
        val panel = ArrayList<View>()
        fun place(parent: ViewGroup, v: View, params: ViewGroup.LayoutParams) {
            parent.addView(v, params)
            if (parent === stage) panel += v
        }

        // 玻璃模块：底子已经模糊过，玻璃自己再糊一层；磨砂的发白用 glassTint 的白色散射做；
        // 边带按模块尺寸给，折射取斜面一半
        fun glass(x: Float, y: Float, w: Float, h: Float, radiusPt: Float, bevelPt: Float = 14f): LiquidGlassView {
            val v = LiquidGlassView(this).apply {
                enableDynamicBackground = true
                cornerRadius = pxF(radiusPt)
                enableAdaptiveTint = false
                enableSensorHighlight = false
                enablePressEffect = false
                blurAmount = CC_BLUR_AMOUNT
                bevelWidth = pxF(bevelPt)
                refractionHeight = pxF(bevelPt / 2f)
                edgeSoftness = pxF(2f)
                dispersionStrength = 0.06f
                edgeHighlightOpacity = 80f
                glassTint = CC_FROST
            }
            place(stage, v, lp(x, y, w, h))
            extraGlassViews += v
            if (firstGlass == null) firstGlass = v
            return v
        }
        fun icon(parent: ViewGroup, res: Int, x: Float, y: Float, w: Float, h: Float, tint: Int? = white): ImageView {
            val v = ImageView(this).apply {
                setImageResource(res)
                imageTintList = tint?.let { ColorStateList.valueOf(it) }
                scaleType = ImageView.ScaleType.FIT_XY
            }
            place(parent, v, lp(x, y, w, h))
            return v
        }
        fun iconAt(parent: ViewGroup, res: Int, cx: Float, cy: Float, w: Float, h: Float, tint: Int? = white) =
            icon(parent, res, cx - w / 2f, cy - h / 2f, w, h, tint)
        fun oval(color: Int) = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        fun circle(parent: ViewGroup, x: Float, y: Float, size: Float, color: Int): FrameLayout {
            val v = FrameLayout(this).apply { background = oval(color) }
            place(parent, v, lp(x, y, size, size))
            return v
        }
        fun makeText(text: String, sizePt: Float, color: Int, bold: Boolean) = TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_PX, pxF(sizePt))
            setTextColor(color)
            typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.SANS_SERIF
            includeFontPadding = false
        }
        fun smallIcon(res: Int, tint: Int) = ImageView(this).apply {
            setImageResource(res)
            imageTintList = ColorStateList.valueOf(tint)
            scaleType = ImageView.ScaleType.FIT_XY
        }
        // 按大写字母顶边定位：Roboto 关掉 includeFontPadding 后，视图顶到大写顶边差 0.217em
        fun textCapTop(parent: ViewGroup, text: String, x: Float, capTop: Float, sizePt: Float, color: Int, bold: Boolean = false): TextView {
            val v = makeText(text, sizePt, color, bold)
            place(parent, v, FrameLayout.LayoutParams(wrapContent, wrapContent).apply {
                leftMargin = px(x)
                topMargin = px(capTop - sizePt * 0.217f)
            })
            return v
        }
        // 副标题后面跟上下箭头的那种行
        fun subtitleRow(parent: ViewGroup, text: String, x: Float, capTop: Float, color: Int, chevron: Boolean): TextView {
            val tv = makeText(text, 13f, color, bold = false)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(tv, LinearLayout.LayoutParams(wrapContent, wrapContent))
                if (chevron) {
                    addView(smallIcon(R.drawable.ic_cc_chevron_updown, color),
                        LinearLayout.LayoutParams(px(8f), px(12f)).apply { marginStart = px(5.5f) })
                }
            }
            place(parent, row, FrameLayout.LayoutParams(wrapContent, wrapContent).apply {
                leftMargin = px(x)
                topMargin = px(capTop - 13f * 0.217f)
            })
            return tv
        }
        // 网络开关：激活态实心蓝 / 绿，非激活半透明白；主页和二级页共用一份状态，点一下翻转
        fun toggle(
            parent: ViewGroup, x: Float, y: Float, size: Float, res: Int, iw: Float, ih: Float,
            activeColor: Int, get: () -> Boolean, set: (Boolean) -> Unit, onChange: (Boolean) -> Unit = {}
        ) {
            val c = circle(parent, x, y, size, CC_INACTIVE)
            iconAt(c, res, size / 2f, size / 2f, iw, ih)
            fun apply() {
                (c.background as GradientDrawable).setColor(if (get()) activeColor else CC_INACTIVE)
                onChange(get())
            }
            apply()
            c.setOnClickListener { set(!get()); apply() }
        }
        // 可切换的圆形玻璃按钮：激活态整圆填色（方向锁 / 手电是白，录屏是红），图标换色
        fun toggleCircle(
            x: Float, y: Float, res: Int, iw: Float, ih: Float, activeBg: Int, activeIcon: Int,
            get: () -> Boolean, set: (Boolean) -> Unit
        ): LiquidGlassView {
            val g = glass(x, y, 72f, 72f, 36f, 12f)
            val fillView = View(this).apply { background = oval(activeBg) }
            g.addView(fillView, full())
            val iv = iconAt(g, res, 36f, 36f, iw, ih)
            fun apply() {
                val on = get()
                fillView.visibility = if (on) View.VISIBLE else View.INVISIBLE
                iv.imageTintList = ColorStateList.valueOf(if (on) activeIcon else white)
            }
            apply()
            g.setOnClickListener { set(!get()); apply() }
            return g
        }
        // 子视图裁到圆角内（滑杆的填充）
        fun clipRounded(v: View, radiusPt: Float) {
            v.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, pxF(radiusPt))
                }
            }
            v.clipToOutline = true
        }
        // 能拖的滑杆：白色填充从底部升起；拖动时不让舞台把手势抢去做下拉
        fun slider(
            x: Float, y: Float, res: Int, iw: Float, ih: Float, iconTint: Int, iconTintOnFill: Int,
            get: () -> Float, set: (Float) -> Unit
        ): LiquidGlassView {
            val g = glass(x, y, 72f, 160f, 36f, 12f)
            clipRounded(g, 36f)
            val fill = View(this).apply {
                setBackgroundColor(0xFBFFFFFF.toInt())
                pivotY = px(160f).toFloat()
            }
            g.addView(fill, FrameLayout.LayoutParams(matchParent, px(160f)))
            val iv = iconAt(g, res, 36.5f, 125f, iw, ih, iconTint)
            fun apply() {
                val f = get()
                fill.scaleY = f
                // 填充盖过图标时图标换色
                iv.imageTintList = ColorStateList.valueOf(if (f > 0.3f) iconTintOnFill else iconTint)
            }
            apply()
            g.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                        v.parent.requestDisallowInterceptTouchEvent(true)
                        set((1f - ev.y / v.height).coerceIn(0f, 1f))
                        apply()
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.parent.requestDisallowInterceptTouchEvent(false)
                        true
                    }
                    else -> false
                }
            }
            return g
        }

        when (controlCenterPage) {
            ControlCenterPage.MAIN -> {
                // 顶部：加号、电源（点电源切换 demo 控件的显示）
                icon(stage, R.drawable.ic_cc_plus, 47f, 31.3f, 12.3f, 12.3f)
                icon(stage, R.drawable.ic_cc_power, 369f, 30f, 15.5f, 15.5f).apply {
                    setPadding(px(12f), px(12f), px(12f), px(12f))
                    layoutParams = lp(357f, 18f, 39.5f, 39.5f)
                    setOnClickListener { toggleControlCenterChrome() }
                }
                // 状态行：信号点 + No Service + Wi-Fi；方向锁 + 100% + 充电电池
                place(stage, LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(smallIcon(R.drawable.ic_cc_signal_dots, 0x66FFFFFF), LinearLayout.LayoutParams(px(22f), px(3.5f)))
                    addView(makeText("No Service", 17f, white, bold = true),
                        LinearLayout.LayoutParams(wrapContent, wrapContent).apply { marginStart = px(5.7f) })
                    addView(smallIcon(R.drawable.ic_cc_wifi, white),
                        LinearLayout.LayoutParams(px(17f), px(12f)).apply { marginStart = px(5f) })
                }, FrameLayout.LayoutParams(wrapContent, px(20f)).apply {
                    leftMargin = px(53f)
                    topMargin = px(82.5f)
                })
                place(stage, LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(smallIcon(R.drawable.ic_cc_lock_rotation, white), LinearLayout.LayoutParams(px(15f), px(13.8f)))
                    addView(makeText("100%", 17f, white, bold = true),
                        LinearLayout.LayoutParams(wrapContent, wrapContent).apply { marginStart = px(3.5f) })
                    addView(ImageView(this@ProfessionalDemoActivity).apply {
                        setImageResource(R.drawable.ic_cc_battery)
                        scaleType = ImageView.ScaleType.FIT_XY
                    }, LinearLayout.LayoutParams(px(31f), px(16f)).apply { marginStart = px(7f) })
                }, FrameLayout.LayoutParams(wrapContent, px(20f)).apply {
                    gravity = Gravity.END
                    rightMargin = px(430f - 377.2f)
                    topMargin = px(82.5f)
                })

                // 网络模块 2×2：大圆 60pt，右下 2×2 小圆 27pt；点模块空白处展开二级页
                glass(46.5f, 137f, 160f, 160f, 40f).also { t ->
                    t.setOnClickListener {
                        controlCenterPage = ControlCenterPage.CONNECTIVITY
                        showScene(Scene.CONTROL_CENTER)
                    }
                    toggle(t, 13.5f, 13.8f, 60f, R.drawable.ic_cc_airplane, 23.3f, 20.7f, CC_BLUE,
                        { state.airplane }, { state.airplane = it })
                    toggle(t, 90f, 13.8f, 60f, R.drawable.ic_cc_airdrop, 22.7f, 21f, CC_BLUE,
                        { state.airdrop }, { state.airdrop = it })
                    toggle(t, 13.5f, 87.5f, 60f, R.drawable.ic_cc_wifi, 24.3f, 17.3f, CC_BLUE,
                        { state.wifi }, { state.wifi = it })
                    toggle(t, 87.2f, 87.7f, 27f, R.drawable.ic_cc_cellular, 17f, 11.3f, CC_GREEN,
                        { state.cellular }, { state.cellular = it })
                    toggle(t, 119.8f, 87.7f, 27f, R.drawable.ic_cc_bluetooth, 8f, 13f, CC_BLUE,
                        { state.bluetooth }, { state.bluetooth = it })
                    toggle(t, 87.2f, 120.5f, 27f, R.drawable.ic_cc_hotspot, 16.7f, 9.7f, CC_BLUE,
                        { state.hotspot }, { state.hotspot = it })
                    // VPN 没配置：灰圆 + 半透明图标，不可点
                    circle(t, 119.8f, 120.5f, 27f, CC_DISABLED).also {
                        iconAt(it, R.drawable.ic_cc_vpn, 13.5f, 13.5f, 12f, 15.3f).alpha = 0.45f
                    }
                }
                // 正在播放
                glass(223f, 137f, 160f, 160f, 40f).also { t ->
                    t.addView(View(this).apply {
                        background = GradientDrawable().apply {
                            cornerRadius = pxF(12f)
                            setColor(CC_INSET)
                        }
                    }, lp(13.5f, 13.5f, 56f, 56f))
                    circle(t, 104.5f, 13.5f, 43f, CC_INSET).also {
                        iconAt(it, R.drawable.ic_cc_airplay, 21.5f, 21.5f, 18.3f, 18f)
                    }
                    textCapTop(t, "Not Playing", 17f, 90f, 15f, white, bold = true)
                    iconAt(t, R.drawable.ic_cc_backward, 35f, 136f, 24f, 14f, CC_CONTROL_DIM)
                    iconAt(t, R.drawable.ic_cc_play, 80.5f, 135.7f, 21.3f, 24f)
                    iconAt(t, R.drawable.ic_cc_forward, 126f, 136f, 24f, 14f, CC_CONTROL_DIM)
                }
                // 第二行：方向锁（激活：白底红图标）、屏幕镜像、亮度、音量
                toggleCircle(46.5f, 313.5f, R.drawable.ic_cc_lock_rotation, 38f, 34.8f, 0xF7FFFFFF.toInt(), CC_RED,
                    { state.rotationLock }, { state.rotationLock = it })
                glass(134.7f, 313.5f, 72f, 72f, 36f, 12f).also {
                    iconAt(it, R.drawable.ic_cc_mirror, 36f, 36f, 34f, 30f)
                }
                slider(223f, 313.5f, R.drawable.ic_cc_sun, 27.3f, 27.3f, white, CC_YELLOW,
                    { state.brightness }, { state.brightness = it })
                slider(311.3f, 313.5f, R.drawable.ic_cc_speaker_slash, 22.7f, 25f, white, CC_ON_WHITE,
                    { state.volume }, { state.volume = it })
                // 专注模式：点月亮切换
                glass(46.5f, 402f, 160f, 72f, 36f, 12f).also { t ->
                    val moon = circle(t, 14.5f, 14.5f, 43f, CC_MOON_CIRCLE)
                    iconAt(moon, R.drawable.ic_cc_moon, 21.5f, 21.5f, 21f, 21f)
                    fun applyFocus() {
                        (moon.background as GradientDrawable).setColor(if (state.focus) CC_INDIGO else CC_MOON_CIRCLE)
                    }
                    applyFocus()
                    moon.setOnClickListener { state.focus = !state.focus; applyFocus() }
                    t.addView(LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        addView(makeText("Focus", 15f, white, bold = true),
                            LinearLayout.LayoutParams(wrapContent, wrapContent))
                        addView(smallIcon(R.drawable.ic_cc_chevron_updown, CC_SUBTITLE),
                            LinearLayout.LayoutParams(px(8f), px(12f)).apply { marginStart = px(5.5f) })
                    }, FrameLayout.LayoutParams(wrapContent, px(72f)).apply { leftMargin = px(67.5f) })
                }
                // 右侧页面指示
                iconAt(stage, R.drawable.ic_cc_heart, 406.7f, 411f, 15.7f, 14.3f)
                iconAt(stage, R.drawable.ic_cc_music_note, 406.7f, 466f, 16f, 18f, CC_RAIL_DIM)
                iconAt(stage, R.drawable.ic_cc_antenna, 406.7f, 522f, 18f, 17f, CC_RAIL_DIM)
                // 第四、五行圆形玻璃按钮
                fun glassCircle(x: Float, y: Float, res: Int, w: Float, h: Float) =
                    glass(x, y, 72f, 72f, 36f, 12f).also { iconAt(it, res, 36f, 36f, w, h) }
                toggleCircle(46.5f, 490f, R.drawable.ic_cc_flashlight, 13f, 33f, 0xF7FFFFFF.toInt(), CC_ON_WHITE,
                    { state.flashlight }, { state.flashlight = it })
                glassCircle(134.7f, 490f, R.drawable.ic_cc_timer, 34f, 34f)
                glassCircle(223f, 490f, R.drawable.ic_cc_calculator, 26.3f, 37.7f)
                glassCircle(311.3f, 490f, R.drawable.ic_cc_camera, 37f, 27f)
                glassCircle(46.5f, 578.5f, R.drawable.ic_cc_qr, 33f, 33f)
                toggleCircle(134.7f, 578.5f, R.drawable.ic_cc_record, 33f, 33f, CC_RED, white,
                    { state.record }, { state.record = it })
            }
            ControlCenterPage.CONNECTIVITY -> {
                // 点模块外的空白处收回主页
                stage.setOnClickListener {
                    controlCenterPage = ControlCenterPage.MAIN
                    showScene(Scene.CONTROL_CENTER)
                }
                fun row(y: Float, title: String, titleColor: Int = white): LiquidGlassView =
                    glass(46.5f, y, 336.5f, 72f, 36f, 12f).also { t ->
                        t.isClickable = true
                        textCapTop(t, title, 67f, 22.3f, 15f, titleColor, bold = true)
                    }
                fun tile(x: Float, y: Float, title: String): LiquidGlassView =
                    glass(x, y, 160f, 160f, 40f).also { t ->
                        t.isClickable = true
                        textCapTop(t, title, 19.5f, 111f, 15f, white, bold = true)
                    }
                row(120f, "Airplane Mode").also { t ->
                    val sub = subtitleRow(t, "Off", 67f, 39.7f, CC_SUBTITLE, chevron = false)
                    toggle(t, 14.5f, 14.5f, 43f, R.drawable.ic_cc_airplane, 25f, 22.3f, CC_BLUE,
                        { state.airplane }, { state.airplane = it }) { sub.text = if (it) "On" else "Off" }
                }
                tile(46.5f, 208f, "Wi-Fi").also { t ->
                    val sub = subtitleRow(t, "", 19.5f, 129.7f, CC_SUBTITLE, chevron = true)
                    toggle(t, 14.5f, 15f, 43f, R.drawable.ic_cc_wifi, 24f, 17.3f, CC_BLUE,
                        { state.wifi }, { state.wifi = it }) { sub.text = if (it) "Office-5G" else "Off" }
                }
                tile(223f, 208f, "AirDrop").also { t ->
                    val sub = subtitleRow(t, "", 19.5f, 129.7f, CC_SUBTITLE, chevron = true)
                    toggle(t, 14.5f, 15f, 43f, R.drawable.ic_cc_airdrop, 22.7f, 21f, CC_BLUE,
                        { state.airdrop }, { state.airdrop = it }) { sub.text = if (it) "Contacts Only" else "Receiving Off" }
                }
                tile(46.5f, 385f, "Cellular Data").also { t ->
                    val sub = subtitleRow(t, "", 19.5f, 129.7f, CC_SUBTITLE, chevron = false)
                    toggle(t, 14.5f, 15f, 43f, R.drawable.ic_cc_cellular, 27f, 18f, CC_GREEN,
                        { state.cellular }, { state.cellular = it }) { sub.text = if (it) "Primary" else "Off" }
                }
                tile(223f, 385f, "Bluetooth").also { t ->
                    val sub = subtitleRow(t, "", 19.5f, 129.7f, CC_SUBTITLE, chevron = true)
                    toggle(t, 14.5f, 15f, 43f, R.drawable.ic_cc_bluetooth, 13.3f, 21.7f, CC_BLUE,
                        { state.bluetooth }, { state.bluetooth = it }) { sub.text = if (it) "On" else "Off" }
                }
                row(562f, "Personal Hotspot").also { t ->
                    val sub = subtitleRow(t, "", 67f, 39.7f, CC_SUBTITLE, chevron = false)
                    toggle(t, 14.5f, 14.5f, 43f, R.drawable.ic_cc_hotspot, 25.7f, 14.7f, CC_BLUE,
                        { state.hotspot }, { state.hotspot = it }) { sub.text = if (it) "Discoverable" else "Off" }
                }
                // VPN 没配置：整行内容都压暗
                row(650f, "VPN", titleColor = 0x80FFFFFF.toInt()).also { t ->
                    subtitleRow(t, "Off", 67f, 39.7f, 0x59FFFFFF, chevron = false)
                    circle(t, 14.5f, 14.5f, 43f, CC_DISABLED).also {
                        iconAt(it, R.drawable.ic_cc_vpn, 21.5f, 21.5f, 19f, 24f).alpha = 0.45f
                    }
                }
            }
        }

        // 下拉进度 → 画面：背景由清晰渐变到模糊压暗并微微放大，模块从屏幕上边缘外滑到位并淡入，
        // 越靠下的模块走得越远，像整张纸被拉下来
        stage.onProgress = { p ->
            blurView.alpha = p
            scrim.alpha = p
            val s = 1f + 0.05f * p
            homeView.scaleX = s
            homeView.scaleY = s
            blurView.scaleX = s
            blurView.scaleY = s
            val fade = (p * 1.6f).coerceAtMost(1f)
            for (v in panel) {
                v.visibility = if (p > 0f) View.VISIBLE else View.INVISIBLE
                v.alpha = fade
                v.translationY = -(1f - p) * (v.bottom + px(24f))
            }
        }
        // 落定：记住开合状态；在二级页收起时回到主页
        stage.onSettled = { open ->
            controlCenterOpen = open
            if (!open && controlCenterPage != ControlCenterPage.MAIN) {
                controlCenterPage = ControlCenterPage.MAIN
                showScene(Scene.CONTROL_CENTER)
            }
        }
        // 位移按各模块的布局位置算，布局完成后再应用一次
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> stage.applyProgress() }
        stage.setProgressNow(if (controlCenterOpen) 1f else 0f)

        statsSource = firstGlass
        return stage
    }

    /** 控制中心场景藏起 demo 自己的控件和系统栏，截图里只剩控制中心；点右上角电源图标切回 */
    private fun setDemoChromeVisible(visible: Boolean) {
        // 窗口还没挂上时 WindowInsetsController 的 hide/show 会被丢掉，等挂上再做
        if (!window.decorView.isAttachedToWindow) {
            window.decorView.post { setDemoChromeVisible(visible) }
            return
        }
        val vis = if (visible) View.VISIBLE else View.GONE
        sceneBarScroll.visibility = vis
        fabSettings.visibility = vis
        githubButton.visibility = vis
        tvPerformanceOverlay.visibility = if (visible && isMonitoring) View.VISIBLE else View.GONE
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (visible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun toggleControlCenterChrome() {
        controlCenterChromeShown = !controlCenterChromeShown
        setDemoChromeVisible(controlCenterChromeShown)
    }

    /**
     * 控制中心场景的舞台：处理 iOS 那套"下拉打开 / 上滑收起"手势。
     * 竖向拖动超过 touch slop 就从子视图手里接管（子视图要自己拖的，如滑杆，调
     * requestDisallowInterceptTouchEvent 即可）；进度 0..1 由 [onProgress] 映射成画面，
     * 松手按进度和速度决定弹开还是回弹，落定后回调 [onSettled]。
     */
    private class ControlCenterStage(context: Context) : FrameLayout(context) {
        var progress = 0f
            private set
        var onProgress: (Float) -> Unit = {}
        var onSettled: (Boolean) -> Unit = {}

        private val slop = ViewConfiguration.get(context).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        private var dragOriginY = 0f
        private var dragging = false
        private var startProgress = 0f
        private var animator: ValueAnimator? = null
        private var velocity: VelocityTracker? = null

        /** 拉满需要的手指行程 */
        private val range: Float get() = height * 0.4f

        fun setProgressNow(p: Float) {
            progress = p.coerceIn(0f, 1f)
            onProgress(progress)
        }

        fun applyProgress() = onProgress(progress)

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> beginTouch(ev)
                MotionEvent.ACTION_MOVE -> {
                    velocity?.addMovement(ev)
                    if (shouldStartDrag(ev)) return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTracking()
            }
            return false
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    beginTouch(ev)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    velocity?.addMovement(ev)
                    if (!dragging) shouldStartDrag(ev)
                    if (dragging) setProgressNow(startProgress + (ev.y - dragOriginY) / range)
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        val vy = velocity?.let { it.computeCurrentVelocity(1000); it.yVelocity } ?: 0f
                        settle(vy)
                    } else if (ev.actionMasked == MotionEvent.ACTION_UP) {
                        performClick()
                    }
                    endTracking()
                    return true
                }
            }
            return super.onTouchEvent(ev)
        }

        override fun performClick(): Boolean = super.performClick()

        private fun beginTouch(ev: MotionEvent) {
            animator?.cancel()
            downX = ev.x
            downY = ev.y
            dragging = false
            velocity?.recycle()
            velocity = VelocityTracker.obtain().also { it.addMovement(ev) }
        }

        /** 竖向位移过了 slop 且大于横向就开始拖；关着时只认下拉，开着时只认上滑 */
        private fun shouldStartDrag(ev: MotionEvent): Boolean {
            if (dragging) return true
            val dy = ev.y - downY
            val dx = ev.x - downX
            if (abs(dy) < slop || abs(dy) < abs(dx)) return false
            if (progress <= 0f && dy < 0f) return false
            if (progress >= 1f && dy > 0f) return false
            dragging = true
            startProgress = progress
            dragOriginY = ev.y
            return true
        }

        private fun endTracking() {
            velocity?.recycle()
            velocity = null
        }

        /** 松手：甩得快按方向，否则按进度过没过 40% */
        private fun settle(vy: Float) {
            val open = if (abs(vy) > 600f) vy > 0f else progress > 0.4f
            animateTo(if (open) 1f else 0f)
        }

        private fun animateTo(target: Float) {
            animator?.cancel()
            var cancelled = false
            animator = ValueAnimator.ofFloat(progress, target).apply {
                duration = (180f + 260f * abs(target - progress)).toLong()
                interpolator = DecelerateInterpolator(2f)
                addUpdateListener { setProgressNow(it.animatedValue as Float) }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationCancel(animation: Animator) {
                        cancelled = true
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        if (!cancelled) onSettled(target >= 1f)
                    }
                })
                start()
            }
        }
    }

    /**
     * 桌面截图按 1/4 解码，用库的 CPU 模糊跑一遍（半径 12 ≈ 全分辨率 48px，约 16pt），跨页复用。
     * iOS 控制中心的底子模糊得并不重：dock 图标还是一团团分开的色块，图标之间的黑壁纸也还是黑的。
     * 截图顶部 50pt 是桌面的状态栏和灵动岛，控制中心的底子里没有这些，先用旁边的壁纸色抹平
     */
    private fun buildControlCenterBackdrop(): Bitmap {
        val opts = BitmapFactory.Options().apply {
            inSampleSize = 4
            inMutable = true
        }
        val src = BitmapFactory.decodeResource(resources, R.drawable.ios_control_center_bg, opts)
        val ptPx = src.width / 430f
        val fill = src.getPixel((40f * ptPx).toInt(), (30f * ptPx).toInt())
        Canvas(src).drawRect(0f, 0f, src.width.toFloat(), 50f * ptPx, Paint().apply { color = fill })
        val blurred = AdvancedFastBlur().blur(src, 12f, 1f)
        // 模糊结果来自库的位图池，拷一份自己持有
        val result = blurred.copy(Bitmap.Config.ARGB_8888, false)
        src.recycle()
        return result
    }

    /** 场景 4：液态融合（拖动圆形玻璃靠近胶囊 dock，边缘 smin 黏连合并；API 33+） */
    private fun buildMergeScene(): View {
        val root = FrameLayout(this)
        root.addView(createColorScroll())

        val panelW = dp(320)
        val panelH = dp(340)
        val mergeGlass = newExtraGlass(999f).apply {
            layoutParams = FrameLayout.LayoutParams(panelW, panelH).apply {
                gravity = Gravity.CENTER
            }
            enableDynamicBackground = true
        }
        statsSource = mergeGlass

        // 主形状 = 底部胶囊 dock；副形状 = 可拖动的圆形玻璃
        val w = panelW.toFloat()
        val h = panelH.toFloat()
        val dockH = dpF(72)
        val dockHalfW = dpF(120)
        mergeGlass.setPrimaryShape(
            android.graphics.RectF(w / 2f - dockHalfW, h - dockH - dpF(16), w / 2f + dockHalfW, h - dpF(16)),
            dockH / 2f
        )

        val bubbleR = dpF(44)
        var bx = w / 2f
        var by = h * 0.30f
        fun applyBubble() {
            mergeGlass.setSecondaryShape(
                android.graphics.RectF(bx - bubbleR, by - bubbleR, bx + bubbleR, by + bubbleR),
                bubbleR,
                dpF(40)
            )
        }
        applyBubble()

        // 拖动气泡（listener 优先于内部 onTouchEvent，融合场景不需要弹性缩放）
        mergeGlass.setOnTouchListener { v, e ->
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN,
                android.view.MotionEvent.ACTION_MOVE -> {
                    bx = e.x.coerceIn(bubbleR, w - bubbleR)
                    by = e.y.coerceIn(bubbleR, h - bubbleR)
                    applyBubble()
                }
                android.view.MotionEvent.ACTION_UP -> v.performClick()
            }
            true
        }
        root.addView(mergeGlass)

        // 提示文字
        root.addView(TextView(this).apply {
            text = getString(R.string.merge_hint)
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = systemBarTop + dp(58)  // 让开状态栏 + 右上角性能悬浮窗
            }
            setPadding(dp(24), 0, dp(24), 0)
        })
        return root
    }

    private fun createColorScroll(): ScrollView {
        val scroll = ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            isVerticalScrollBarEnabled = false
            // content 上下留白是给顶部渐进模糊留的滚入空间；不铺底色的话
            // 这两条会直接露出窗口背景，全屏后就是屏幕顶端一条白带
            setBackgroundColor(COLOR_SCROLL_GUTTER)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(100), 0, dp(100))
        }

        COLOR_BANDS.forEach { (from, to, label) ->
            val block = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160))
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR, intArrayOf(from, to)
                )
            }
            block.addView(TextView(this).apply {
                text = label
                textSize = 24f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setShadowLayer(4f, 2f, 2f, Color.BLACK)
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            })
            content.addView(block)
        }
        scroll.addView(content)
        return scroll
    }

    /** 调参场"图片"背景的默认图：没选自定义图时程序生成一张风景 */
    private fun getOrCreateScenicBitmap(): Bitmap {
        scenicBitmap?.let { return it }
        val w = resources.displayMetrics.widthPixels.coerceAtLeast(320)
        val h = (resources.displayMetrics.heightPixels * 1.2f).toInt().coerceAtLeast(480)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // 落日天空
        paint.shader = LinearGradient(
            0f, 0f, 0f, h * 0.72f,
            intArrayOf(0xFF2C3E70.toInt(), 0xFFB0527A.toInt(), 0xFFFF9966.toInt(), 0xFFFFD194.toInt()),
            floatArrayOf(0f, 0.45f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h * 0.72f, paint)
        paint.shader = null

        // 太阳
        paint.shader = RadialGradient(
            w * 0.5f, h * 0.62f, w * 0.22f,
            intArrayOf(0xFFFFF3B0.toInt(), 0x00FFF3B0), null, Shader.TileMode.CLAMP
        )
        c.drawCircle(w * 0.5f, h * 0.62f, w * 0.22f, paint)
        paint.shader = null
        paint.color = 0xFFFFE29A.toInt()
        c.drawCircle(w * 0.5f, h * 0.62f, w * 0.09f, paint)

        // 远山与近山
        paint.color = 0xFF4A3B5E.toInt()
        c.drawPath(mountainPath(w.toFloat(), h * 0.72f, h * 0.16f, 3), paint)
        paint.color = 0xFF31284A.toInt()
        c.drawPath(mountainPath(w.toFloat(), h * 0.72f, h * 0.10f, 4), paint)

        // 水面
        paint.shader = LinearGradient(
            0f, h * 0.72f, 0f, h.toFloat(),
            intArrayOf(0xFFE8956D.toInt(), 0xFF3C2E5A.toInt()), null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, h * 0.72f, w.toFloat(), h.toFloat(), paint)
        paint.shader = null

        // 水面反光条
        paint.color = 0x66FFE9B0
        var y = h * 0.74f
        var half = w * 0.16f
        while (y < h * 0.95f) {
            c.drawRect(w * 0.5f - half, y, w * 0.5f + half, y + dpF(2), paint)
            y += dpF(10)
            half *= 0.92f
        }

        scenicBitmap = bmp
        return bmp
    }

    private fun mountainPath(w: Float, baseY: Float, peakH: Float, peaks: Int): Path {
        val path = Path()
        path.moveTo(0f, baseY)
        val step = w / peaks
        for (i in 0 until peaks) {
            path.lineTo(step * i + step * 0.5f, baseY - peakH * (0.7f + 0.3f * ((i * 37) % 10) / 10f))
            path.lineTo(step * (i + 1), baseY)
        }
        path.close()
        return path
    }

    /** 动画光斑背景视图（调参场的"动画"背景） */
    private class AnimatedBlobView(context: Context) : View(context) {
        private data class Blob(val color: Int, val phase: Float, val speed: Float, val rx: Float, val ry: Float, val radius: Float)

        private val blobs = listOf(
            Blob(0xFFFF5E7E.toInt(), 0.0f, 1.0f, 0.32f, 0.26f, 0.34f),
            Blob(0xFF56CCF2.toInt(), 1.7f, 0.8f, 0.36f, 0.30f, 0.40f),
            Blob(0xFFB465DA.toInt(), 3.1f, 1.2f, 0.30f, 0.34f, 0.32f),
            Blob(0xFFF2C94C.toInt(), 4.6f, 0.6f, 0.38f, 0.24f, 0.28f),
            Blob(0xFF6FCF97.toInt(), 5.9f, 0.9f, 0.28f, 0.32f, 0.30f)
        )
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var t = 0f
        private val animator = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
            duration = 12000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            animator.start()
        }

        override fun onDetachedFromWindow() {
            animator.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(0xFF14141E.toInt())
            val w = width.toFloat()
            val h = height.toFloat()
            blobs.forEach { b ->
                val cx = w * 0.5f + w * b.rx * cos(t * b.speed + b.phase)
                val cy = h * 0.5f + h * b.ry * sin(t * b.speed * 1.3f + b.phase)
                val r = w * b.radius
                paint.shader = RadialGradient(
                    cx, cy, r,
                    intArrayOf(b.color, b.color and 0x00FFFFFF), null, Shader.TileMode.CLAMP
                )
                canvas.drawCircle(cx, cy, r, paint)
            }
            paint.shader = null
        }
    }

    /**
     * 场景：现成小部件（LiquidGlassTabBar / LiquidGlassTabLayout / LiquidGlassButton / LiquidGlassChip /
     * LiquidGlassFab，全部库默认参数开箱展示）
     *
     * 背景是横向翻页的色块（ViewPager2），玻璃标签页用 LiquidGlassTabLayoutMediator 和它联动：
     * 左右滑背景时玻璃滴跟着翻页进度走，点标签翻页。
     */
    private fun buildWidgetsScene(): View {
        val root = FrameLayout(this)
        val pager = ViewPager2(this).apply { adapter = ColorPageAdapter(COLOR_BANDS) }
        root.addView(pager, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // 顶部玻璃标签条：iOS 26 风格（图标+小字，玻璃滴指示可点可拖）
        val tabTitles = listOf(
            getString(R.string.widgets_tab_1),
            getString(R.string.widgets_tab_2),
            getString(R.string.widgets_tab_3)
        )
        val tabIcons = listOf(
            R.drawable.ic_tab_home,
            R.drawable.ic_tab_explore,
            R.drawable.ic_tab_library
        )
        val tabBar = LiquidGlassTabBar(this).apply {
            enableDynamicBackground = true
            setTabs(tabTitles.zip(tabIcons) { title, iconRes ->
                LiquidGlassTabBar.TabItem(title, ContextCompat.getDrawable(this@ProfessionalDemoActivity, iconRes))
            })
            onTabSelected = { index ->
                showGlassToast(getString(R.string.widgets_toast_tab, tabTitles[index]))
            }
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP
                setMargins(dp(20), systemBarTop + dp(58), dp(20), 0)  // 让开状态栏 + 性能悬浮窗
            }
        }
        root.addView(tabBar)

        // 标签条下面是玻璃标签页：可滑动模式，8 个颜色标签和翻页背景联动
        val tabLayout = LiquidGlassTabLayout(this).apply {
            enableDynamicBackground = true
            tabMode = LiquidGlassTabLayout.MODE_SCROLLABLE
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP
                setMargins(dp(20), systemBarTop + dp(58 + 64 + 12), dp(20), 0)  // 标签条高 64dp
            }
        }
        root.addView(tabLayout)
        LiquidGlassTabLayoutMediator(tabLayout, pager) { tab, position ->
            tab.text = COLOR_BANDS[position].third.substringAfter(' ')
        }.attach()

        // 中央按钮：Regular / Clear 两种材质对比。
        // 注意必须直接挂在 root 下——玻璃捕获直接父容器，包一层透明
        // LinearLayout 的话捕获到的就是空内容，按钮会渲染成黑底
        val regularButton = LiquidGlassButton(this).apply {
            enableDynamicBackground = true
            text = getString(R.string.widgets_button_regular)
            setOnClickListener {
                showGlassToast(getString(R.string.widgets_toast_button, text))
            }
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER
                topMargin = -dp(44)
            }
        }
        root.addView(regularButton)
        root.addView(LiquidGlassButton(this).apply {
            enableDynamicBackground = true
            material = GlassMaterial.CLEAR
            text = getString(R.string.widgets_button_clear)
            setOnClickListener {
                showGlassToast(getString(R.string.widgets_toast_button, text))
            }
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER
                topMargin = dp(44)
            }
        })

        // 按钮下面一组玻璃 chip：操作 chip、三个可多选的筛选 chip、一个带关闭图标的输入 chip。
        // 组是透明容器，背景来源由组下发（指向翻页背景）
        val chipGroup = LiquidGlassChipGroup(this).apply {
            enableDynamicBackground = true
            backdropSource = pager
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER
                topMargin = dp(170)
                leftMargin = dp(20)
                rightMargin = dp(20)
            }
        }
        chipGroup.addView(LiquidGlassChip(this).apply {
            text = getString(R.string.widgets_chip_explore)
            setChipIconResource(R.drawable.ic_tab_explore)
            setOnClickListener { showGlassToast(getString(R.string.widgets_toast_chip, text)) }
        })
        listOf(
            R.string.widgets_chip_photos,
            R.string.widgets_chip_videos,
            R.string.widgets_chip_music
        ).forEachIndexed { index, res ->
            chipGroup.addView(LiquidGlassChip(this).apply {
                text = getString(res)
                isCheckable = true
                isChecked = index == 0
            })
        }
        chipGroup.addView(LiquidGlassChip(this).apply {
            text = getString(R.string.widgets_chip_paris)
            isCloseIconVisible = true
            setOnCloseIconClickListener {
                chipGroup.removeView(this)
                showGlassToast(getString(R.string.widgets_toast_chip_removed, text))
            }
        })
        chipGroup.setOnCheckedStateChangeListener { group, checkedIds ->
            val names = checkedIds.mapNotNull { (group.findViewById<View>(it) as? LiquidGlassChip)?.text }
            showGlassToast(getString(
                R.string.widgets_toast_filters,
                if (names.isEmpty()) getString(R.string.widgets_filters_none) else names.joinToString(", ")
            ))
        }
        root.addView(chipGroup)

        // 左下圆形玻璃 FAB
        root.addView(LiquidGlassFab(this).apply {
            enableDynamicBackground = true
            setIconResource(android.R.drawable.ic_input_add)
            setOnClickListener {
                showGlassToast(getString(R.string.widgets_toast_fab))
            }
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.START or Gravity.BOTTOM
                setMargins(dp(24), 0, 0, dp(96))
            }
        })

        // 本场景不含主 glassView，性能悬浮窗读常规材质按钮的数据
        statsSource = regularButton
        return root
    }

    /**
     * 场景：列表 —— 每一行是独立的 [LiquidGlassListItem]，装在 [LiquidGlassListGroup] 里，
     * 两种排布可切换：合并（行贴边拼成一块面板，只有组外沿有透镜边缘）和分离（每行独立圆角卡片）。
     * 中间一组用自带内容（contentView：开关、滑杆），行只负责按位置画玻璃形状。
     *
     * 组是透明容器，直接父容器采不到壁纸，所以背景由组统一下发到每一行（backdropSource）。
     * 不指向 root：root 里还有其他玻璃行，互相采样会套娃。
     */
    private fun buildListScene(): View {
        val root = FrameLayout(this)

        // 背景：与文字场景同一张壁纸，两张上下拼接可滚动，单独一层给玻璃当 backdropSource
        val backdrop = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            repeat(2) { i ->
                addView(ImageView(this@ProfessionalDemoActivity).apply {
                    setImageResource(R.drawable.text_backdrop)
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    if (i == 1) scaleY = -1f
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                })
            }
        }
        root.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setBackgroundColor(0xFF060B18.toInt())
            addView(backdrop)
        }, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), 0, dp(20), 0)
        }

        fun detail(textRes: Int) = TextView(this).apply {
            text = getString(textRes)
            textSize = 14f
            setTextColor(0xCCFFFFFF.toInt())
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
            setLineSpacing(0f, 1.2f)
        }

        fun row(
            titleRes: Int,
            subRes: Int?,
            iconRes: Int,
            detailRes: Int? = null,
            trailingRes: Int? = null
        ) = LiquidGlassListItem(this).apply {
            headline = getString(titleRes)
            supportingText = subRes?.let { getString(it) }
            setLeadingIconResource(iconRes)
            trailingText = trailingRes?.let { getString(it) }
            if (detailRes != null) {
                // 点击整行展开详情，尾部箭头跟着转 180°
                setTrailingIconResource(R.drawable.ic_expand_more)
                expandedView = detail(detailRes)
            }
        }

        // 背景来源和动态背景由组下发到每一行，行自己不用再设
        fun newGroup() = LiquidGlassListGroup(this).apply {
            enableDynamicBackground = true
            backdropSource = backdrop
        }
        val rowParams = {
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // 合并 / 分离切换
        val hint = TextView(this).apply {
            textSize = 13f
            setTextColor(0xCCFFFFFF.toInt())
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
            gravity = Gravity.CENTER
        }
        val groups = mutableListOf<LiquidGlassListGroup>()
        fun applyStyle(style: LiquidGlassListGroup.Style) {
            groups.forEach { it.style = style }
            hint.text = getString(
                if (style == LiquidGlassListGroup.Style.MERGED) R.string.group_hint_merged
                else R.string.group_hint_separated
            )
        }
        val styles = LiquidGlassListGroup.Style.entries
        column.addView(
            buildChipToggle(
                listOf(getString(R.string.group_style_merged), getString(R.string.group_style_separated)),
                0
            ) { index -> applyStyle(styles[index]) },
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(20)
            }
        )

        // 一组四行，每行点击展开；位置（首/中/末）由组按当前样式分配
        val group = newGroup()
        listOf(
            row(R.string.group_wifi_title, R.string.group_wifi_sub, R.drawable.ic_tab_home,
                detailRes = R.string.group_wifi_detail),
            row(R.string.group_bt_title, R.string.group_bt_sub, R.drawable.ic_tab_explore,
                detailRes = R.string.group_bt_detail),
            row(R.string.group_notif_title, R.string.group_notif_sub, R.drawable.ic_tab_library,
                detailRes = R.string.group_notif_detail),
            row(R.string.group_display_title, R.string.group_display_sub, android.R.drawable.ic_menu_view,
                detailRes = R.string.group_display_detail, trailingRes = R.string.group_display_trailing)
        ).forEach { group.addView(it, rowParams()) }
        groups += group
        column.addView(group, rowParams())

        // 自带内容：行里放任意视图（开关、滑杆），行只负责按位置画玻璃形状
        column.addView(TextView(this).apply {
            text = getString(R.string.group_custom_caption)
            textSize = 12f
            setTextColor(0xB3FFFFFF.toInt())
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
        }, rowParams().apply {
            topMargin = dp(24)
            bottomMargin = dp(8)
            leftMargin = dp(4)
        })
        val custom = newGroup()
        val airplaneSwitch = Switch(this).apply {
            setOnCheckedChangeListener { _, on ->
                showGlassToast(getString(
                    if (on) R.string.group_custom_airplane_on else R.string.group_custom_airplane_off
                ))
            }
        }
        custom.addView(LiquidGlassListItem(this).apply {
            contentView = LinearLayout(this@ProfessionalDemoActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(8), dp(12), dp(8))
                addView(TextView(this@ProfessionalDemoActivity).apply {
                    text = getString(R.string.group_custom_airplane)
                    textSize = 16f
                    setTextColor(Color.WHITE)
                    setShadowLayer(8f, 0f, 2f, Color.BLACK)
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                addView(airplaneSwitch)
            }
            // 点整行也能拨开关
            setOnClickListener { airplaneSwitch.toggle() }
        }, rowParams())
        custom.addView(LiquidGlassListItem(this).apply {
            contentView = LinearLayout(this@ProfessionalDemoActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(12), dp(12), dp(12))
                addView(ImageView(this@ProfessionalDemoActivity).apply {
                    setImageResource(R.drawable.ic_cc_sun)
                    setColorFilter(Color.WHITE)
                    contentDescription = getString(R.string.group_custom_brightness)
                }, LinearLayout.LayoutParams(dp(22), dp(22)))
                addView(SeekBar(this@ProfessionalDemoActivity).apply {
                    max = 100
                    progress = 70
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(8)
                })
            }
        }, rowParams())
        groups += custom
        column.addView(custom, rowParams())

        // 单独一行：四角全圆，不可展开
        val single = newGroup()
        single.addView(
            row(R.string.group_signout_title, null, android.R.drawable.ic_lock_power_off),
            rowParams()
        )
        groups += single
        column.addView(single, rowParams().apply { topMargin = dp(24) })

        column.addView(hint, rowParams().apply { topMargin = dp(20) })
        applyStyle(LiquidGlassListGroup.Style.MERGED)

        root.addView(column, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER })

        statsSource = group.getChildAt(0) as LiquidGlassView
        return root
    }

    /**
     * 抽屉里的玻璃染色卡片：色板 + 强度滑杆，直接改当前场景所有玻璃的 glassTint。
     * 染色跟其他参数一样跨场景保留，附加玻璃创建时由 syncGlassParams 带上。
     */
    private fun buildTintCard(root: LinearLayout) {
        val card = addCard(root, getString(R.string.section_glass_tint))

        // 初值跟着主玻璃当前的染色走
        val current = glassView.glassTint
        var hueRes = R.string.tint_none
        var hue = if (Color.alpha(current) == 0) Color.TRANSPARENT else current or 0xFF000000.toInt()
        var strength = if (Color.alpha(current) == 0) 0.30f else Color.alpha(current) / 255f
        TINT_SWATCHES.firstOrNull { it.second == hue }?.let { hueRes = it.first }

        val readout = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT)
            setPadding(0, dp(8), 0, 0)
        }
        fun refreshReadout() {
            readout.text = if (hue == Color.TRANSPARENT) {
                getString(R.string.tint_readout_none)
            } else {
                getString(
                    R.string.tint_readout,
                    getString(hueRes),
                    "#%06X".format(hue and 0xFFFFFF),
                    (strength * 100).toInt()
                )
            }
        }
        fun applyTint() {
            applyGlass {
                if (hue == Color.TRANSPARENT) it.glassTint = Color.TRANSPARENT
                else it.setGlassTint(hue, strength)
            }
            refreshReadout()
        }

        val (swatchRow, selectSwatch) = buildTintSwatchRow { labelRes, color ->
            hueRes = labelRes
            hue = color
            applyTint()
        }
        selectSwatch(hue)

        // 色板一行放不下就横向滚动（窄屏 + 9 个色块）
        card.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(swatchRow)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        })
        card.addView(readout)
        card.addView(SeekBar(this).apply {
            max = 100
            progress = (strength * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    strength = p / 100f
                    // 还没选色就拖强度：默认给蓝色，否则滑杆看着像坏了
                    if (hue == Color.TRANSPARENT) {
                        hueRes = R.string.tint_blue
                        hue = 0xFF0A84FF.toInt()
                        selectSwatch(hue)
                    }
                    applyTint()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
        refreshReadout()
    }

    /**
     * 圆形色板行（浅色抽屉底上用）
     *
     * @return 行视图 + 一个"按颜色回选"的回调（外部改了颜色时用来同步选中态）
     */
    private fun buildTintSwatchRow(
        onPick: (labelRes: Int, color: Int) -> Unit
    ): Pair<View, (Int) -> Unit> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val dots = mutableListOf<View>()
        var selected = 0

        fun render() {
            dots.forEachIndexed { i, dot ->
                val color = TINT_SWATCHES[i].second
                dot.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    // "无染色"没有颜色可画，给一块浅灰当占位
                    setColor(if (color == Color.TRANSPARENT) COLOR_SEG_BG else color)
                    setStroke(
                        dp(if (i == selected) 3 else 1),
                        if (i == selected) COLOR_ACCENT else 0x33000000
                    )
                }
            }
        }

        TINT_SWATCHES.forEachIndexed { i, (labelRes, color) ->
            val dot = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply {
                    setMargins(0, 0, dp(10), 0)
                }
                setOnClickListener {
                    selected = i
                    render()
                    onPick(labelRes, color)
                }
            }
            dots += dot
            row.addView(dot)
        }
        render()

        return row to { color: Int ->
            val idx = TINT_SWATCHES.indexOfFirst { it.second == color }
            if (idx >= 0 && idx != selected) {
                selected = idx
                render()
            }
        }
    }

    /** 创建随主 glassView 参数同步的附属玻璃组件 */
    private fun newExtraGlass(cornerRadiusPx: Float): LiquidGlassView {
        val view = LiquidGlassView(this).apply {
            enableDynamicBackground = true
            cornerRadius = cornerRadiusPx
        }
        syncGlassParams(view)
        view.cornerRadius = cornerRadiusPx  // 圆角保持各自形状
        extraGlassViews += view
        return view
    }

    private fun syncGlassParams(target: LiquidGlassView) {
        val src = glassView
        target.useHardwareBlurWhenPossible = src.useHardwareBlurWhenPossible
        target.debugApiLevelCap = src.debugApiLevelCap
        target.useShaderPipeline = src.useShaderPipeline
        target.material = src.material
        target.bevelWidth = src.bevelWidth
        target.refractionHeight = src.refractionHeight
        target.dispersionStrength = src.dispersionStrength
        target.enableSensorHighlight = src.enableSensorHighlight
        target.enableAdaptiveTint = src.enableAdaptiveTint
        target.refractionOutward = src.refractionOutward
        target.refractionNoFold = src.refractionNoFold
        target.refractionFalloff = src.refractionFalloff
        target.adaptiveLensScale = src.adaptiveLensScale
        target.glassTint = src.glassTint
        target.accessibilityMode = src.accessibilityMode
        target.enablePressEffect = src.enablePressEffect
        target.pressScale = src.pressScale
        target.elasticity = src.elasticity
        target.enableBackdropBlur = src.enableBackdropBlur
        target.blurAmount = src.blurAmount
        target.saturation = src.saturation
        target.overLight = src.overLight
        target.enableEdgeHighlight = src.enableEdgeHighlight
        target.edgeHighlightBorderWidth = src.edgeHighlightBorderWidth
        target.edgeHighlightOpacity = src.edgeHighlightOpacity
        target.enableChromaticAberration = src.enableChromaticAberration
        target.enableChromaticDispersion = src.enableChromaticDispersion
        target.aberrationIntensity = src.aberrationIntensity
        target.displacementScale = src.displacementScale
        target.displacementMode = src.displacementMode
        target.aberrationRedOffset = src.aberrationRedOffset
        target.aberrationGreenOffset = src.aberrationGreenOffset
        target.aberrationBlueOffset = src.aberrationBlueOffset
        target.blurMethod = src.blurMethod
        target.chromaticAberrationMode = src.chromaticAberrationMode
        target.globalDownsampleFactor = src.globalDownsampleFactor
        target.aberrationDownsample = src.aberrationDownsample
    }

    /** 面板参数应用到当前场景的全部玻璃组件 */
    private fun applyGlass(block: (LiquidGlassView) -> Unit) {
        block(glassView)
        extraGlassViews.forEach(block)
    }

    // ==================== 调试面板 ====================

    private fun createDrawer(): View {
        val drawer = LinearLayout(this).apply {
            layoutParams = DrawerLayout.LayoutParams(
                (resources.displayMetrics.widthPixels * 0.86f).toInt(),
                DrawerLayout.LayoutParams.MATCH_PARENT
            ).apply { gravity = GravityCompat.END }
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(COLOR_BG)
            setPadding(dp(16), dp(44), dp(16), dp(12))
        }

        drawer.addView(TextView(this).apply {
            text = getString(R.string.debug_panel_title)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(COLOR_TEXT)
            setPadding(dp(6), 0, 0, dp(4))
        })

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            isVerticalScrollBarEnabled = false
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
        }
        buildPanel(content)
        scroll.addView(content)
        drawer.addView(scroll)
        return drawer
    }

    private fun buildPanel(root: LinearLayout) {
        // ---------- 性能 ----------
        val perfCard = addCard(root, getString(R.string.section_performance))
        addSwitchRow(perfCard, getString(R.string.switch_performance_overlay), true) { checked ->
            tvPerformanceOverlay.visibility = if (checked) View.VISIBLE else View.GONE
            isMonitoring = checked
        }
        tvDebugInfo = TextView(this).apply {
            textSize = 11f
            setTextColor(COLOR_TEXT)
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(4), 0, dp(4))
            text = getString(R.string.debug_info_waiting)
        }
        perfCard.addView(tvDebugInfo)

        // ---------- 渲染路径 ----------
        val pathCard = addCard(root, getString(R.string.section_render_path))
        val initialPath = when {
            !glassView.useHardwareBlurWhenPossible -> 2
            !glassView.useShaderPipeline -> 1
            else -> 0
        }
        addSegmented(
            pathCard,
            listOf(
                getString(R.string.render_lens),
                getString(R.string.render_classic_gpu),
                getString(R.string.render_force_cpu)
            ),
            initialPath
        ) { index ->
            applyGlass {
                it.useHardwareBlurWhenPossible = index != 2
                it.useShaderPipeline = index == 0
            }
            lensGroup.visibility = if (index == 0) View.VISIBLE else View.GONE
            cpuOptionsGroup.visibility = if (index == 2) View.VISIBLE else View.GONE
        }
        addNote(pathCard, getString(R.string.gpu_render_desc))

        // 模拟 API 级别：钳制库的管线分层，在高版本设备上预览低版本效果
        addLabel(pathCard, getString(R.string.simulate_api_label))
        addSegmented(
            pathCard,
            listOf(getString(R.string.api_cap_device), "33–35", "31–32", "≤ 30"),
            0
        ) { index ->
            val cap = when (index) {
                1 -> 35
                2 -> 32
                3 -> 30
                else -> Int.MAX_VALUE
            }
            applyGlass { it.debugApiLevelCap = cap }
        }
        addNote(pathCard, getString(R.string.simulate_api_desc))

        // Liquid Glass 2.0 透镜选项（仅透镜路径时显示）
        lensGroup = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (initialPath == 0) View.VISIBLE else View.GONE
        }
        pathCard.addView(lensGroup)
        buildLensOptions(lensGroup)

        // CPU 算法选项（仅强制 CPU 时显示）
        cpuOptionsGroup = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (initialPath == 2) View.VISIBLE else View.GONE
        }
        pathCard.addView(cpuOptionsGroup)
        buildCpuOptions(cpuOptionsGroup)

        // ---------- 玻璃参数（GPU + CPU 通用） ----------
        val glassCard = addCard(root, getString(R.string.section_glass_params))

        addSwitchRow(glassCard, getString(R.string.switch_enable_blur), glassView.enableBackdropBlur) { checked ->
            applyGlass { it.enableBackdropBlur = checked }
        }
        addSlider(glassCard, 100, (glassView.blurAmount * 100).toInt(),
            { getString(R.string.blur_amount, it / 100f) }) { p ->
            applyGlass { it.blurAmount = p / 100f }
        }
        addSlider(glassCard, 100, (glassView.saturation - 100).toInt(),
            { getString(R.string.saturation_value, it + 100) }) { p ->
            applyGlass { it.saturation = (p + 100).toFloat() }
        }
        addSlider(glassCard, 999, glassView.cornerRadius.toInt(),
            { getString(R.string.corner_radius_value, it.toFloat()) }) { p ->
            // 圆角只作用于主组件，附属组件保持各自形状
            glassView.cornerRadius = p.toFloat()
        }
        addSwitchRow(glassCard, getString(R.string.switch_over_light), glassView.overLight) { checked ->
            applyGlass { it.overLight = checked }
        }
        addSwitchRow(glassCard, getString(R.string.switch_enable_edge_highlight), glassView.enableEdgeHighlight) { checked ->
            applyGlass { it.enableEdgeHighlight = checked }
        }
        addSlider(glassCard, 100, ((glassView.edgeHighlightBorderWidth - 0.5f) / 4.5f * 100).toInt(),
            { getString(R.string.border_width, 0.5f + it / 100f * 4.5f) }) { p ->
            applyGlass { it.edgeHighlightBorderWidth = 0.5f + p / 100f * 4.5f }
        }
        addSlider(glassCard, 100, glassView.edgeHighlightOpacity.toInt(),
            { getString(R.string.highlight_opacity, it.toFloat()) }) { p ->
            applyGlass { it.edgeHighlightOpacity = p.toFloat() }
        }

        // ---------- 玻璃染色 ----------
        buildTintCard(root)

        // ---------- 交互 · 点击效果 ----------
        val interactionCard = addCard(root, getString(R.string.section_interaction))
        addSwitchRow(interactionCard, getString(R.string.switch_press_effect), glassView.enablePressEffect) { checked ->
            applyGlass { it.enablePressEffect = checked }
        }
        // 按压缩放 0.80 - 1.20（< 1 按下缩小，> 1 按下放大）
        addSlider(interactionCard, 40, ((glassView.pressScale - 0.8f) * 100f).roundToInt(),
            { getString(R.string.press_scale_value, 0.8f + it / 100f) }) { p ->
            applyGlass { it.pressScale = 0.8f + p / 100f }
        }
        // 弹性系数 0 - 0.50（拖拽时的拉伸强度）
        addSlider(interactionCard, 50, (glassView.elasticity * 100).toInt(),
            { getString(R.string.elasticity_value, it / 100f) }) { p ->
            applyGlass { it.elasticity = p / 100f }
        }

        // ---------- 色彩效果 ----------
        val colorCard = addCard(root, getString(R.string.section_color_effect))
        val initialEffect = when {
            glassView.enableChromaticDispersion -> 2
            glassView.enableChromaticAberration -> 1
            else -> 0
        }
        addSegmented(
            colorCard,
            listOf(
                getString(R.string.effect_none),
                getString(R.string.algorithm_aberration),
                getString(R.string.algorithm_dispersion)
            ),
            initialEffect
        ) { index ->
            when (index) {
                0 -> applyGlass {
                    it.enableChromaticDispersion = false
                    it.enableChromaticAberration = false
                }
                1 -> applyGlass {
                    it.enableChromaticDispersion = false
                    it.enableChromaticAberration = true
                }
                2 -> applyGlass {
                    it.enableChromaticAberration = false
                    it.enableChromaticDispersion = true
                }
            }
            aberrationGroup.visibility = if (index == 1) View.VISIBLE else View.GONE
            dispersionGroup.visibility = if (index == 2) View.VISIBLE else View.GONE
        }

        // 色差参数
        aberrationGroup = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (initialEffect == 1) View.VISIBLE else View.GONE
        }
        colorCard.addView(aberrationGroup)
        buildAberrationOptions(aberrationGroup)

        // 色散参数
        dispersionGroup = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (initialEffect == 2) View.VISIBLE else View.GONE
        }
        colorCard.addView(dispersionGroup)
        buildDispersionOptions(dispersionGroup)

        // ---------- 背景与语言 ----------
        val miscCard = addCard(root, getString(R.string.section_background_language))
        addButton(miscCard, getString(R.string.button_change_background)) {
            checkPermissionAndOpenPicker()
        }
        addButton(miscCard, getString(R.string.button_open_github)) { openRepo() }
        addButton(miscCard, getLanguageSwitchButtonText()) {
            val prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val currentLang = prefs.getString(KEY_LANGUAGE, LANG_ENGLISH) ?: LANG_ENGLISH
            switchLanguage(if (currentLang == LANG_CHINESE) LANG_ENGLISH else LANG_CHINESE)
        }
    }

    /** Liquid Glass 2.0 透镜管线选项 */
    private fun buildLensOptions(group: LinearLayout) {
        addNote(group, getString(R.string.lens_note))

        // 材质：Regular / Clear
        addLabel(group, getString(R.string.lens_material))
        addSegmented(
            group,
            listOf(getString(R.string.material_regular), getString(R.string.material_clear)),
            if (glassView.material == GlassMaterial.CLEAR) 1 else 0
        ) { index ->
            applyGlass { it.material = if (index == 1) GlassMaterial.CLEAR else GlassMaterial.REGULAR }
        }

        addSwitchRow(group, getString(R.string.switch_sensor_highlight), glassView.enableSensorHighlight) { checked ->
            applyGlass { it.enableSensorHighlight = checked }
        }
        addSwitchRow(group, getString(R.string.switch_adaptive_tint), glassView.enableAdaptiveTint) { checked ->
            applyGlass { it.enableAdaptiveTint = checked }
        }
        addSwitchRow(group, getString(R.string.switch_refraction_no_fold), glassView.refractionNoFold) { checked ->
            applyGlass { it.refractionNoFold = checked }
        }
        addSwitchRow(group, getString(R.string.switch_refraction_outward), glassView.refractionOutward) { checked ->
            applyGlass { it.refractionOutward = checked }
        }
        addSwitchRow(group, getString(R.string.switch_adaptive_lens_scale), glassView.adaptiveLensScale) { checked ->
            applyGlass { it.adaptiveLensScale = checked }
        }

        // 斜面宽度 2-120 px
        addSlider(group, 118, (glassView.bevelWidth - 2f).toInt(),
            { getString(R.string.lens_bevel, it + 2f) }) { p ->
            applyGlass { it.bevelWidth = p + 2f }
        }
        // 折射强度 0-200 px（属性上限 300，采样有安全钳制不会越界）
        addSlider(group, 200, glassView.refractionHeight.toInt(),
            { getString(R.string.lens_refraction, it.toFloat()) }) { p ->
            applyGlass { it.refractionHeight = p.toFloat() }
        }
        // 折射衰减指数 0-4（0 = 平方斜面）
        addSlider(group, 40, (glassView.refractionFalloff * 10f).toInt(),
            { getString(R.string.lens_falloff, it / 10f) }) { p ->
            applyGlass { it.refractionFalloff = p / 10f }
        }
        // 色散强度 0-1
        addSlider(group, 100, (glassView.dispersionStrength * 100f).toInt(),
            { getString(R.string.lens_dispersion, it / 100f) }) { p ->
            applyGlass { it.dispersionStrength = p / 100f }
        }

        // 无障碍不透明降级（演示 Reduce Transparency 行为）
        addSwitchRow(
            group,
            getString(R.string.switch_a11y_opaque),
            glassView.accessibilityMode == GlassAccessibilityMode.FORCE_OPAQUE
        ) { checked ->
            applyGlass {
                it.accessibilityMode =
                    if (checked) GlassAccessibilityMode.FORCE_OPAQUE else GlassAccessibilityMode.AUTO
            }
        }
    }

    private fun buildCpuOptions(group: LinearLayout) {
        addNote(group, getString(R.string.section_cpu_options))

        // 模糊算法
        val methods = listOf(
            getString(R.string.blur_method_smart) to BlurMethod.SMART,
            getString(R.string.blur_method_box) to BlurMethod.BOX_BLUR,
            getString(R.string.blur_method_box_cpp) to BlurMethod.BOX_BLUR_CPP,
            getString(R.string.blur_method_iir) to BlurMethod.IIR_GAUSSIAN,
            getString(R.string.blur_method_neon) to BlurMethod.IIR_GAUSSIAN_NEON,
            getString(R.string.blur_method_box3) to BlurMethod.BOX3,
            getString(R.string.blur_method_downsample) to BlurMethod.DOWNSAMPLE
        )
        addLabel(group, getString(R.string.section_blur_method))
        val spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, methods.map { it.first })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.setSelection(methods.indexOfFirst { it.second == glassView.blurMethod }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                applyGlass { it.blurMethod = methods[position].second }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        group.addView(spinner)

        // 色差实现
        addLabel(group, getString(R.string.section_aberration_method))
        val modes = listOf(
            ChromaticAberrationEffect.PerformanceMode.AUTO,
            ChromaticAberrationEffect.PerformanceMode.CPP,
            ChromaticAberrationEffect.PerformanceMode.KOTLIN
        )
        addSegmented(
            group,
            listOf(getString(R.string.impl_auto), "C++", "Kotlin"),
            modes.indexOf(glassView.chromaticAberrationMode).coerceAtLeast(0)
        ) { index ->
            applyGlass { it.chromaticAberrationMode = modes[index] }
        }

        addSwitchRow(group, getString(R.string.switch_bilinear_interpolation), glassView.aberrationUseBilinearInterpolation) { checked ->
            applyGlass { it.aberrationUseBilinearInterpolation = checked }
        }
        addSwitchRow(group, getString(R.string.switch_high_quality), glassView.highQualityBlur) { checked ->
            applyGlass { it.highQualityBlur = checked }
        }
        addSwitchRow(group, getString(R.string.switch_enable_optimized_capture), glassView.enableOptimizedCapture) { checked ->
            applyGlass { it.enableOptimizedCapture = checked }
        }

        // 全局下采样 0.25 - 1.0
        addSlider(group, 100, ((glassView.globalDownsampleFactor - 0.25f) / 0.75f * 100).toInt(),
            { getString(R.string.global_downsample_value, 0.25f + it / 100f * 0.75f) }) { p ->
            applyGlass { it.globalDownsampleFactor = 0.25f + p / 100f * 0.75f }
        }
        // 色差下采样 0.25 - 1.0
        addSlider(group, 100, ((glassView.aberrationDownsample - 0.25f) / 0.75f * 100).toInt(),
            { getString(R.string.aberration_downsample_value, 0.25f + it / 100f * 0.75f) }) { p ->
            applyGlass { it.aberrationDownsample = 0.25f + p / 100f * 0.75f }
        }
    }

    private fun buildAberrationOptions(group: LinearLayout) {
        // 强度 0 - 10
        addSlider(group, 100, (glassView.aberrationIntensity * 10).toInt(),
            { getString(R.string.aberration_value, it / 10f) }) { p ->
            applyGlass { it.aberrationIntensity = p / 10f }
        }
        // 位移强度 0 - 200
        addSlider(group, 200, glassView.displacementScale.toInt(),
            { getString(R.string.displacement_scale_value, it.toFloat()) }) { p ->
            applyGlass { it.displacementScale = p.toFloat() }
        }
        // 位移模式
        addLabel(group, getString(R.string.displacement_mode))
        val dispModes = listOf(DisplacementMode.STANDARD, DisplacementMode.POLAR, DisplacementMode.PROMINENT)
        addSegmented(
            group,
            listOf(
                getString(R.string.disp_mode_standard),
                getString(R.string.disp_mode_polar),
                getString(R.string.disp_mode_prominent)
            ),
            dispModes.indexOf(glassView.displacementMode).coerceAtLeast(0)
        ) { index ->
            applyGlass { it.displacementMode = dispModes[index] }
        }

        // 通道偏移
        addLabel(group, getString(R.string.channel_offset_advanced))
        addSlider(group, 200, (glassView.aberrationRedOffset * 500 + 100).toInt(),
            { getString(R.string.red_offset, (it - 100) / 500f) }) { p ->
            applyGlass { it.aberrationRedOffset = (p - 100) / 500f }
        }
        addSlider(group, 200, (glassView.aberrationGreenOffset * 500 + 100).toInt(),
            { getString(R.string.green_offset, (it - 100) / 500f) }) { p ->
            applyGlass { it.aberrationGreenOffset = (p - 100) / 500f }
        }
        addSlider(group, 200, (glassView.aberrationBlueOffset * 500 + 100).toInt(),
            { getString(R.string.blue_offset, (it - 100) / 500f) }) { p ->
            applyGlass { it.aberrationBlueOffset = (p - 100) / 500f }
        }
    }

    private fun buildDispersionOptions(group: LinearLayout) {
        addNote(group, getString(R.string.dispersion_cpu_only_note))

        // 预设
        addLabel(group, getString(R.string.dispersion_preset))
        val presets = listOf(
            Triple(getString(R.string.preset_glass), 100f, 1.5f to 7f),
            Triple(getString(R.string.preset_diamond), 80f, 2.4f to 15f),
            Triple(getString(R.string.preset_crystal), 120f, 1.8f to 10f),
            Triple(getString(R.string.preset_rainbow), 150f, 1.3f to 20f),
            Triple(getString(R.string.preset_subtle), 200f, 1.2f to 3f)
        )

        lateinit var updateSliders: () -> Unit

        val spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, presets.map { it.first })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val (_, thickness, rest) = presets[position]
                val (factor, gain) = rest
                applyGlass {
                    it.dispersionThickness = thickness
                    it.dispersionFactor = factor
                    it.dispersionGain = gain
                }
                updateSliders()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        group.addView(spinner)

        // 厚度 50-200
        val (tvThickness, seekThickness) = addSlider(group, 150, (glassView.dispersionThickness - 50).toInt(),
            { getString(R.string.dispersion_thickness, it + 50f) }) { p ->
            applyGlass { it.dispersionThickness = p + 50f }
        }
        // 系数 1.0-3.0
        val (tvFactor, seekFactor) = addSlider(group, 100, ((glassView.dispersionFactor - 1f) * 50).toInt(),
            { getString(R.string.dispersion_factor, 1f + it / 50f) }) { p ->
            applyGlass { it.dispersionFactor = 1f + p / 50f }
        }
        // 增益 0-50
        val (tvGain, seekGain) = addSlider(group, 50, glassView.dispersionGain.toInt(),
            { getString(R.string.dispersion_gain, it.toFloat()) }) { p ->
            applyGlass { it.dispersionGain = p.toFloat() }
        }
        // 色散下采样 0.25-1.0
        addSlider(group, 100, ((glassView.dispersionDownsample - 0.25f) / 0.75f * 100).toInt(),
            { getString(R.string.dispersion_downscale, 0.25f + it / 100f * 0.75f) }) { p ->
            applyGlass { it.dispersionDownsample = 0.25f + p / 100f * 0.75f }
        }

        updateSliders = {
            seekThickness.progress = (glassView.dispersionThickness - 50).toInt()
            tvThickness.text = getString(R.string.dispersion_thickness, glassView.dispersionThickness)
            seekFactor.progress = ((glassView.dispersionFactor - 1f) * 50).toInt()
            tvFactor.text = getString(R.string.dispersion_factor, glassView.dispersionFactor)
            seekGain.progress = glassView.dispersionGain.toInt()
            tvGain.text = getString(R.string.dispersion_gain, glassView.dispersionGain)
        }
    }

    // ==================== 面板 UI 构件 ====================

    private fun addCard(parent: LinearLayout, title: String): LinearLayout {
        parent.addView(TextView(this).apply {
            text = title
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(COLOR_TEXT_DIM)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(18)
                bottomMargin = dp(6)
                marginStart = dp(8)
            }
        })
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dpF(14)
                setColor(COLOR_CARD)
            }
            setPadding(dp(14), dp(6), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        parent.addView(card)
        return card
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(COLOR_TEXT)
            setPadding(0, dp(12), 0, dp(4))
        })
    }

    private fun addNote(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 11f
            setTextColor(COLOR_TEXT_DIM)
            setPadding(0, dp(6), 0, dp(4))
        })
    }

    private fun addButton(parent: LinearLayout, text: String, onClick: () -> Unit) {
        parent.addView(Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        })
    }

    private fun addSwitchRow(
        parent: LinearLayout,
        label: String,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ): Switch {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        row.addView(TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(COLOR_TEXT)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        val sw = Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, c -> onChange(c) }
        }
        row.addView(sw)
        parent.addView(row)
        return sw
    }

    private fun addSlider(
        parent: LinearLayout,
        max: Int,
        initial: Int,
        format: (Int) -> String,
        onChange: (Int) -> Unit
    ): Pair<TextView, SeekBar> {
        val clamped = initial.coerceIn(0, max)
        val tv = TextView(this).apply {
            text = format(clamped)
            textSize = 13f
            setTextColor(COLOR_TEXT)
            setPadding(0, dp(8), 0, 0)
        }
        val seek = SeekBar(this).apply {
            this.max = max
            progress = clamped
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    tv.text = format(p)
                    if (fromUser) onChange(p)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        parent.addView(tv)
        parent.addView(seek)
        return tv to seek
    }

    /** 分段选择控件（iOS Segmented Control 风格） */
    private fun addSegmented(
        parent: LinearLayout,
        options: List<String>,
        selectedIndex: Int,
        onSelect: (Int) -> Unit
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
                bottomMargin = dp(4)
            }
            background = GradientDrawable().apply {
                cornerRadius = dpF(10)
                setColor(COLOR_SEG_BG)
            }
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }

        val labels = mutableListOf<TextView>()
        var current = selectedIndex.coerceIn(0, options.size - 1)

        fun render() {
            labels.forEachIndexed { i, tv ->
                if (i == current) {
                    tv.background = GradientDrawable().apply {
                        cornerRadius = dpF(8)
                        setColor(Color.WHITE)
                    }
                    tv.setTextColor(COLOR_TEXT)
                    tv.typeface = Typeface.DEFAULT_BOLD
                } else {
                    tv.background = null
                    tv.setTextColor(0xFF666666.toInt())
                    tv.typeface = Typeface.DEFAULT
                }
            }
        }

        options.forEachIndexed { i, label ->
            val tv = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, dp(7))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    if (current != i) {
                        current = i
                        render()
                        onSelect(i)
                    }
                }
            }
            labels += tv
            row.addView(tv)
        }
        render()
        parent.addView(row)
    }

    // ==================== 性能监控 ====================

    private fun startPerformanceMonitoring() {
        val runnable = object : Runnable {
            override fun run() {
                if (isMonitoring) updatePerformanceDisplay()
                performanceHandler.postDelayed(this, 500L)
            }
        }
        performanceHandler.post(runnable)
    }

    private fun updatePerformanceDisplay() {
        val stats = (statsSource ?: glassView).lastFrameStats ?: return
        val isGpu = stats.effectName.startsWith("GPU")

        // 只显示实测绘制频率；GPU 录制耗时不包含实际着色和屏幕呈现。
        val drawRate = stats.drawFps.takeIf { it > 0 }?.toString() ?: "--"

        fun fmt(ms: Float) = String.format("%.2f", ms)

        val overlayText = if (isGpu) {
            "Draw/s: $drawRate\n${stats.effectName}\nrecord ${fmt(stats.totalMs)}ms"
        } else {
            val blurTag = if (stats.blurRecomputed) "" else "*"
            val effectTag = if (stats.effectRecomputed) "" else "*"
            "Draw/s: $drawRate  CPU\n" +
                "capture ${fmt(stats.captureMs)}ms\n" +
                "blur    ${fmt(stats.blurMs)}ms$blurTag\n" +
                "effect  ${fmt(stats.effectMs)}ms$effectTag\n" +
                "total   ${fmt(stats.totalMs)}ms"
        }

        val debugText = if (isGpu) {
            "${stats.effectName} · RenderEffect\n" +
                "record ${fmt(stats.totalMs)}ms · $drawRate draw/s"
        } else {
            "CPU · ${glassView.blurMethod}\n" +
                "capture ${fmt(stats.captureMs)} | blur ${fmt(stats.blurMs)} | " +
                "effect ${fmt(stats.effectMs)}\n" +
                "total ${fmt(stats.totalMs)}ms · $drawRate draw/s · " +
                "${stats.processedWidth}×${stats.processedHeight}\n" +
                "(* = cache hit)"
        }

        // 实际 / 生效 API（模拟低版本时显示箭头）
        val apiLine = if (glassView.debugApiLevelCap != Int.MAX_VALUE) {
            "API ${Build.VERSION.SDK_INT}→${glassView.effectiveApiLevel}(sim)"
        } else {
            "API ${Build.VERSION.SDK_INT}"
        }

        tvPerformanceOverlay.text = "$overlayText\n$apiLine"
        tvDebugInfo.text = "$debugText\n$apiLine"
    }

    // ==================== 背景图片 ====================

    private fun checkPermissionAndOpenPicker() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        when {
            ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED ->
                openImagePicker()
            else -> permissionLauncher.launch(permission)
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        imagePickerLauncher.launch(intent)
    }

    private fun loadBackgroundImage(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (bitmap != null) {
                customBackgroundBitmap?.recycle()
                customBackgroundBitmap = bitmap
                playgroundBackdrop = PlaygroundBackdrop.IMAGE
                showScene(Scene.PLAYGROUND)
                drawerLayout.closeDrawer(GravityCompat.END)
                showGlassToast(getString(R.string.toast_image_selected))
            } else {
                showGlassToast(getString(R.string.toast_no_image_selected))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load image", e)
            showGlassToast(getString(R.string.toast_no_image_selected))
        }
    }

    // ==================== 语言 ====================

    private fun applySavedLanguage() {
        val prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        // 默认英文；用户在面板里切换过语言后跟随其选择
        val savedLang = prefs.getString(KEY_LANGUAGE, LANG_ENGLISH) ?: LANG_ENGLISH
        setAppLocale(savedLang)
    }

    private fun setAppLocale(languageCode: String) {
        val locale = when (languageCode) {
            LANG_ENGLISH -> Locale.ENGLISH
            else -> Locale.CHINESE
        }
        Locale.setDefault(locale)
        val config = Configuration(resources.configuration)
        config.setLocale(locale)
        @Suppress("DEPRECATION")
        resources.updateConfiguration(config, resources.displayMetrics)
    }

    private fun switchLanguage(languageCode: String) {
        getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_LANGUAGE, languageCode).apply()
        val intent = intent
        finish()
        startActivity(intent)
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun getLanguageSwitchButtonText(): String {
        val prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val currentLang = prefs.getString(KEY_LANGUAGE, LANG_ENGLISH) ?: LANG_ENGLISH
        return if (currentLang == LANG_CHINESE) {
            getString(R.string.button_language_english)
        } else {
            getString(R.string.button_language_chinese)
        }
    }

    // ==================== 生命周期 ====================

    override fun onDestroy() {
        super.onDestroy()
        dismissGlassBottomSheet()
        performanceHandler.removeCallbacksAndMessages(null)
        customBackgroundBitmap?.recycle()
        customBackgroundBitmap = null
        scenicBitmap?.recycle()
        scenicBitmap = null
        controlCenterBackdrop?.recycle()
        controlCenterBackdrop = null
        controlCenterHome?.recycle()
        controlCenterHome = null
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
            drawerLayout.closeDrawer(GravityCompat.END)
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    /** 小部件场景的翻页背景：每页一整屏渐变色块，中间一行大字（给玻璃按钮折射） */
    private class ColorPageAdapter(
        private val bands: List<Triple<Int, Int, String>>
    ) : RecyclerView.Adapter<ColorPageAdapter.Holder>() {

        class Holder(val label: TextView) : RecyclerView.ViewHolder(label)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val label = TextView(parent.context).apply {
                // ViewPager2 要求每页铺满
                layoutParams = RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT,
                    RecyclerView.LayoutParams.MATCH_PARENT
                )
                gravity = Gravity.CENTER
                textSize = 40f
                setTextColor(Color.WHITE)
                setShadowLayer(6f, 2f, 2f, Color.BLACK)
            }
            return Holder(label)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val (from, to, text) = bands[position]
            holder.label.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(from, to))
            holder.label.text = text
        }

        override fun getItemCount(): Int = bands.size
    }
}
